# School District Cost Model Explorer -- Setup Instructions

This is a single-file R Shiny app (`SchoolDistrictCostModelApp.R`) for the school
district cost-modeling case. No other files are needed to run it.

## 1. Requirements

- R (any recent version) and RStudio.
- Four packages: `shiny`, `ggplot2`, `data.table`, `scales`.

If you don't already have these installed, run once in the R console:

```r
install.packages(c("shiny", "ggplot2", "data.table", "scales"))
```

## 2. Running the app

1. Save `SchoolDistrictCostModelApp.R` into its own folder (any folder is fine).
2. Open that file in RStudio.
3. Click the **Run App** button in the top-right of the script editor pane
   (or run `shiny::runApp()` from the console with that folder as your
   working directory).

## 3. Heads-up on the first launch

Tab 7 ("Assessing Model Fit") runs 1,000 simulated district enrollment
patterns to compare a cost model against reality. That computation is the
slowest thing the app does.

- **First launch:** expect a delay of roughly 1-2 minutes while this runs.
- **Every launch after that:** near-instant. The app saves the results to a
  small file, `model_fit_cache.rds`, in the same folder as the script, and
  reuses it automatically as long as the file is still there.

You don't need to do anything to enable this -- it's automatic. If your
folder happens to be read-only, the app will just recompute it every time
(slower, but it won't break anything).

## 4. Notes

- Everything is self-contained in the one `.R` file -- no external data
  files, no hardcoded folder paths. It should run identically on any
  machine with R/RStudio and the four packages above.
- If you ever want a completely fresh recompute of the Tab 7 simulation
  (e.g., after editing the model), just delete `model_fit_cache.rds` and
  relaunch -- it will regenerate automatically.

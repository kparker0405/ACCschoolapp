###############################################################################
# School District Cost Model Explorer (Shiny)
#
# Walks through cost-behavior modeling for a school district -- fixed vs.
# variable costs and step costs -- via four tabs: Background, Elementary,
# High School, and District, each simulating staffing/building costs from
# detailed rules about how elementary, middle, and high schools are staffed.
#
# Cost rates (used throughout):
#   Supplies: $1,000/student, fully variable, no capacity constraint
#   Teachers: $80,000/teacher
#   Schools:  $1,500,000/school
#
# To run: open this file in RStudio and click "Run App" (requires the
# shiny, ggplot2, data.table, and scales packages).
###############################################################################

library(shiny)
library(ggplot2)
library(data.table)
library(scales)

# Forces R to always print numbers in plain fixed notation (e.g. 1500000,
# not 1.5e+06) everywhere in this app -- axis labels, dollar figures, and
# any other formatted number -- regardless of how large or small it is.
options(scipen = 999)

# ---- Cost rates -------------------------------------------------------------
teacher_capacity <- 25 # students per elementary classroom / per MS-HS section
supply_rate <- 1000 # $/student, fully variable
teacher_cost <- 80000 # $/teacher
school_cost <- 1500000 # $/school
district_mc_max_n <- 20000 # max district enrollment traced on the "6. Modeling Choices: District" tab

# Michigan Ross brand palette. Ross's confirmed brand colors are PMS 282 blue
# (#00274C) and PMS 7406 maize (#FFCB05); the style guide references a wider
# palette of "secondary accents" without publishing exact hex values, so
# "facility" and "model" below are Ross-blue/maize-family tints chosen to
# stay on-brand while giving enough separation for stacked/grouped charts.
palette_cb <- c(
  ink = "#00274C", # Ross Blue -- primary line/axis color
  highlow = "#FFCB05", # Ross Maize -- primary accent
  facility = "#5B87A6", # lighter Ross Blue tint -- secondary accent
  model = "#9A7B4F" # warm bronze/gold tint -- tertiary accent
)

# Callout text highlighted on the Elementary tab's chart: one entry for the
# building-expense jump, one for the School Supplies ramp, plus one for each
# of the three "waves" of teacher hiring (wave = which classroom, 1st/2nd/3rd,
# a hire is for). The supplies text is built from supply_rate (not a hard-
# coded dollar figure), so it always reflects the model's actual parameter.
elem_wave_text <- c(
  "building" = paste0(
    "Building expense occurs when the school enrolls its first student ",
    "and remains constant until the school reaches capacity."
  ),
  "supplies" = paste0(
    "Each student costs $",
    format(supply_rate, big.mark = ","),
    " in supplies. Thus, the school supplies cost increases smoothly ",
    "and linearly with enrollment."
  ),
  "1" = "A teacher is hired for each grade when the first student in that grade shows up.",
  "2" = paste0(
    "Once the first classroom in the grade fills, a second teacher needs to be ",
    "hired. These are somewhat staggered because students don't arrive across ",
    "all the grades completely evenly."
  ),
  "3" = paste0(
    "The third set of grade-school teachers are even more staggered as the ",
    "effects of uneven grade arrivals grow."
  )
)

# Callout text highlighted on the High School tab's chart: one entry
# explaining the vertical jumps (teachers hired in blocks of six), one
# explaining the horizontal steps (why their width varies).
high_wave_text <- c(
  "vertical" = paste0(
    "Teachers are always hired in groups of six -- one new teacher per ",
    "subject -- since every student takes all six subjects, so each ",
    "subject's section count crosses its own capacity threshold at the ",
    "same moment."
  ),
  "horizontal" = paste0(
    "The width of each flat step depends on the precise order students ",
    "arrive in -- whether the next student's grade already has room in an ",
    "existing section, or whether admitting them requires opening a brand ",
    "new section (and with it, another set of six teachers)."
  )
)

###############################################################################
# Core staffing/building rules
#
#   Elementary (K-5): self-contained classrooms. Each classroom holds up to
#   25 students and is staffed by 1 teacher. A school has room for at most 3
#   classrooms per grade (so an elementary school's true capacity, split
#   evenly across 6 grades, is 3 x 25 x 6 = 450 students).
#
#   Middle (6-8) and High (9-12): subject teachers. Every student takes all
#   6 subjects (English, Science, Math, Foreign Language, History, Specials).
#   Each subject section holds up to 25 students, and a section can only
#   include students from ONE grade (a 9th grade Math section can't also
#   seat 10th graders) -- but a teacher's 6 daily sections of a subject CAN
#   span different grades. So the number of sections a subject needs is the
#   SUM of each grade's own ceiling(enrollment/25), not a single ceiling of
#   the pooled enrollment, and teachers for that subject come in blocks of 6
#   sections (ceiling(sections/6)). A middle school has 36 classrooms and a
#   high school has 48; divided evenly across 6 subjects, that's a cap of 6
#   teachers/subject in a middle school and 8 teachers/subject in a high
#   school. If every grade were split perfectly evenly across the classes,
#   that cap works out to 900 students (middle) or 1,200 (high) -- but since
#   grades round up to sections separately, actual capacity is usually a bit
#   lower, the same way an elementary school rarely reaches its 450 max.
###############################################################################

grade_levels <- c("K", as.character(1:12)) # 13 grades, K-12
elem_grades <- c("K", "1", "2", "3", "4", "5")
middle_grades <- c("6", "7", "8")
high_grades <- c("9", "10", "11", "12")

elem_classrooms_per_grade_cap <- 3 # elementary: max classrooms per grade, per school

subjects <- c(
  "English",
  "Science",
  "Math",
  "Foreign Language",
  "History",
  "Specials"
)
teacher_classes_per_day <- 6 # a MS/HS teacher teaches 6 sections/day
teacher_student_capacity <- teacher_capacity * teacher_classes_per_day # 25 x 6 = 150

middle_classrooms_per_school <- 36
high_classrooms_per_school <- 48

# These are the THEORETICAL max capacities per school, reached only if every
# grade happened to divide perfectly evenly into 25-student sections. Kept
# around for that "theoretical maximum" narrative -- actual capacity, once
# each grade is rounded up to sections separately, is usually a bit lower.
middle_capacity_per_school <- floor(
  middle_classrooms_per_school / length(subjects)
) *
  teacher_student_capacity
high_capacity_per_school <- floor(
  high_classrooms_per_school / length(subjects)
) *
  teacher_student_capacity

middle_classrooms_per_subject <- floor(
  middle_classrooms_per_school / length(subjects)
) # 6
high_classrooms_per_subject <- floor(
  high_classrooms_per_school / length(subjects)
) # 8

# NOTE: the whole-district staffing snapshot (elem/mid/high enrollment,
# teachers, schools, and costs) is computed on the District tab by running
# the actual multi-building simulations (simulate_multi_elem() /
# simulate_multi_secondary()) rather than a closed-form approximation.

# ---- One-school, one-student-at-a-time simulations -------------------------
# Fills a SINGLE school from empty using an ordered sequence of grade draws
# (already filtered to the relevant grade band), and records the running cost
# after each student is admitted. A building expense hits at student 1. A
# teacher gets added only when the relevant classroom/subject count crosses
# another integer threshold. The elementary version stops the moment the next
# student in line belongs to a grade that has already filled its 3 classrooms
# (75 students) -- since that student would need a second building, this one
# school's story ends there, almost always short of the 450-student ceiling.
simulate_elem_school <- function(seq_grades) {
  grade_tally <- setNames(rep(0L, length(elem_grades)), elem_grades)
  classroom_tally <- setNames(rep(0L, length(elem_grades)), elem_grades)
  n_teachers <- 0L
  building_added <- FALSE
  running_cost <- 0

  n_max <- length(seq_grades)
  students <- integer(n_max)
  cum_cost <- numeric(n_max)
  cum_teach <- integer(n_max)
  n_admitted <- 0L
  capped_grade <- NA_character_

  # Every classroom a school adds is that grade's 1st, 2nd, or 3rd -- record
  # each hiring event's "wave" number (1/2/3) and the student count at which
  # it happened, so the UI can highlight where each wave of hiring clusters.
  event_students <- integer(0)
  event_wave <- integer(0)

  for (g in seq_grades) {
    if (grade_tally[[g]] >= elem_classrooms_per_grade_cap * teacher_capacity) {
      capped_grade <- g
      break
    }

    grade_tally[[g]] <- grade_tally[[g]] + 1L

    if (!building_added) {
      running_cost <- running_cost + school_cost
      building_added <- TRUE
    }

    new_classrooms <- ceiling(grade_tally[[g]] / teacher_capacity)
    if (new_classrooms > classroom_tally[[g]]) {
      added <- new_classrooms - classroom_tally[[g]]
      n_teachers <- n_teachers + added
      running_cost <- running_cost + added * teacher_cost
      classroom_tally[[g]] <- new_classrooms

      event_students <- c(event_students, n_admitted + 1L)
      event_wave <- c(event_wave, new_classrooms)
    }

    running_cost <- running_cost + supply_rate

    n_admitted <- n_admitted + 1L
    students[n_admitted] <- n_admitted
    cum_cost[n_admitted] <- running_cost
    cum_teach[n_admitted] <- n_teachers
  }

  list(
    trace = data.table(
      students = students[seq_len(n_admitted)],
      total_cost = cum_cost[seq_len(n_admitted)],
      teachers = cum_teach[seq_len(n_admitted)]
    ),
    grade_tally_final = grade_tally,
    capped_grade = capped_grade,
    events = data.table(students = event_students, wave = event_wave)
  )
}

# High school version: every student takes all 6 subjects, but a section
# can't mix grades -- a 9th grade Math section can't also seat 10th graders.
# So the sections a subject needs is the SUM of each grade's own
# ceiling(enrollment/25), and teachers for that subject arrive in blocks of
# 6 sections. All 6 subjects have identical demand (every student takes all
# of them), so they all hit the school's 8-teacher-per-subject ceiling at
# the same moment -- once admitting the next student would push the
# sections-per-subject total past 48 (8 teachers x 6 sections), the school
# stops admitting, almost always short of the 1,200-student theoretical max.
simulate_high_school <- function(seq_grades) {
  grade_tally <- setNames(rep(0L, length(high_grades)), high_grades)
  max_sections_per_subject <- high_classrooms_per_subject *
    teacher_classes_per_day # 48

  sections_per_subject <- 0L
  teachers_per_subject <- 0L
  n_teachers <- 0L
  building_added <- FALSE
  running_cost <- 0

  n_max <- length(seq_grades)
  students <- integer(n_max)
  cum_cost <- numeric(n_max)
  cum_teach <- integer(n_max)
  n_admitted <- 0L
  capped <- FALSE
  capped_grade <- NA_character_

  for (g in seq_grades) {
    old_grade_sections <- ceiling(grade_tally[[g]] / teacher_capacity)
    new_grade_sections <- ceiling((grade_tally[[g]] + 1L) / teacher_capacity)
    new_sections_per_subject <- sections_per_subject +
      (new_grade_sections - old_grade_sections)

    if (new_sections_per_subject > max_sections_per_subject) {
      capped <- TRUE
      capped_grade <- g
      break
    }

    grade_tally[[g]] <- grade_tally[[g]] + 1L
    sections_per_subject <- new_sections_per_subject

    if (!building_added) {
      running_cost <- running_cost + school_cost
      building_added <- TRUE
    }

    new_tps <- ceiling(sections_per_subject / teacher_classes_per_day)
    if (new_tps > teachers_per_subject) {
      added_total <- (new_tps - teachers_per_subject) * length(subjects)
      n_teachers <- n_teachers + added_total
      running_cost <- running_cost + added_total * teacher_cost
      teachers_per_subject <- new_tps
    }

    running_cost <- running_cost + supply_rate

    n_admitted <- n_admitted + 1L
    students[n_admitted] <- n_admitted
    cum_cost[n_admitted] <- running_cost
    cum_teach[n_admitted] <- n_teachers
  }

  list(
    trace = data.table(
      students = students[seq_len(n_admitted)],
      total_cost = cum_cost[seq_len(n_admitted)],
      teachers = cum_teach[seq_len(n_admitted)]
    ),
    capped = capped,
    capped_grade = capped_grade
  )
}

# ---- Multi-building simulations ---------------------------------------------
# These extend the single-school simulations above to a WHOLE grade band
# (potentially several school buildings): instead of stopping once the
# current building's capacity is hit, they open a fresh building and keep
# admitting the same ordered sequence of students there. This is a real,
# order-respecting bin-packing of students into buildings -- not a closed-
# form approximation -- so it correctly captures rounding waste from
# students being split across multiple buildings. Each returns a CUMULATIVE
# districtwide trace, one row per student in that band, in arrival order.

simulate_multi_elem <- function(seq_grades) {
  n_max <- length(seq_grades)
  if (n_max == 0) {
    return(data.table(
      students = integer(0),
      total_cost = numeric(0),
      teachers = integer(0),
      schools = integer(0)
    ))
  }

  grade_tally <- setNames(rep(0L, length(elem_grades)), elem_grades)
  classroom_tally <- setNames(rep(0L, length(elem_grades)), elem_grades)

  total_teachers <- 0L
  total_schools <- 0L
  running_cost <- 0

  students <- integer(n_max)
  cum_cost <- numeric(n_max)
  cum_teach <- integer(n_max)
  cum_sch <- integer(n_max)

  for (i in seq_len(n_max)) {
    g <- seq_grades[i]

    # No building open yet, or this grade has already filled its 3
    # classrooms in the CURRENT building -- open a fresh elementary school
    # (its own 6 grades, all empty) and admit this student there instead.
    if (
      total_schools == 0L ||
        grade_tally[[g]] >= elem_classrooms_per_grade_cap * teacher_capacity
    ) {
      grade_tally <- setNames(rep(0L, length(elem_grades)), elem_grades)
      classroom_tally <- setNames(rep(0L, length(elem_grades)), elem_grades)
      total_schools <- total_schools + 1L
      running_cost <- running_cost + school_cost
    }

    grade_tally[[g]] <- grade_tally[[g]] + 1L

    new_classrooms <- ceiling(grade_tally[[g]] / teacher_capacity)
    if (new_classrooms > classroom_tally[[g]]) {
      added <- new_classrooms - classroom_tally[[g]]
      total_teachers <- total_teachers + added
      running_cost <- running_cost + added * teacher_cost
      classroom_tally[[g]] <- new_classrooms
    }

    running_cost <- running_cost + supply_rate

    students[i] <- i
    cum_cost[i] <- running_cost
    cum_teach[i] <- total_teachers
    cum_sch[i] <- total_schools
  }

  data.table(
    students = students,
    total_cost = cum_cost,
    teachers = cum_teach,
    schools = cum_sch
  )
}

# Generic middle/high version -- classrooms_per_school (36 or 48) and the
# relevant grade band are passed in, since middle and high schools follow
# the identical subject-teacher rule, just with different building sizes.
simulate_multi_secondary <- function(
  seq_grades,
  secondary_grades,
  classrooms_per_school
) {
  n_max <- length(seq_grades)
  if (n_max == 0) {
    return(data.table(
      students = integer(0),
      total_cost = numeric(0),
      teachers = integer(0),
      schools = integer(0)
    ))
  }

  classrooms_per_subject <- floor(classrooms_per_school / length(subjects))
  max_sections_per_subject <- classrooms_per_subject * teacher_classes_per_day

  grade_tally <- setNames(rep(0L, length(secondary_grades)), secondary_grades)
  sections_per_subject <- 0L
  teachers_per_subject <- 0L

  total_teachers <- 0L
  total_schools <- 0L
  running_cost <- 0

  students <- integer(n_max)
  cum_cost <- numeric(n_max)
  cum_teach <- integer(n_max)
  cum_sch <- integer(n_max)

  for (i in seq_len(n_max)) {
    g <- seq_grades[i]

    old_g_sections <- ceiling(grade_tally[[g]] / teacher_capacity)
    new_g_sections <- ceiling((grade_tally[[g]] + 1L) / teacher_capacity)
    would_be <- sections_per_subject + (new_g_sections - old_g_sections)

    # No building open yet, or this student would push some subject's
    # section count past capacity in the CURRENT building -- open a fresh
    # one (a whole new set of subject-teacher slots) and admit there.
    if (total_schools == 0L || would_be > max_sections_per_subject) {
      grade_tally <- setNames(
        rep(0L, length(secondary_grades)),
        secondary_grades
      )
      sections_per_subject <- 0L
      teachers_per_subject <- 0L
      total_schools <- total_schools + 1L
      running_cost <- running_cost + school_cost
      would_be <- 1L # this student is grade g's first in the fresh building
    }

    grade_tally[[g]] <- grade_tally[[g]] + 1L
    sections_per_subject <- would_be

    new_tps <- ceiling(sections_per_subject / teacher_classes_per_day)
    if (new_tps > teachers_per_subject) {
      added <- (new_tps - teachers_per_subject) * length(subjects)
      total_teachers <- total_teachers + added
      running_cost <- running_cost + added * teacher_cost
      teachers_per_subject <- new_tps
    }

    running_cost <- running_cost + supply_rate

    students[i] <- i
    cum_cost[i] <- running_cost
    cum_teach[i] <- total_teachers
    cum_sch[i] <- total_schools
  }

  data.table(
    students = students,
    total_cost = cum_cost,
    teachers = cum_teach,
    schools = cum_sch
  )
}

# Vectorized helper for the District tab: given one band's
# multi-building trace (indexed 1..n by that band's OWN arrival order) and,
# for every overall district step, how many of that band's students have
# arrived so far (pos_vec), look up that band's teachers/schools at every
# overall step in one shot. A position of 0 (no students from this band yet)
# maps to 0 rather than being dropped, which is how R would normally treat a
# 0 index.
band_lookup <- function(trace, pos_vec, col) {
  out <- integer(length(pos_vec))
  hit <- pos_vec > 0
  out[hit] <- trace[[col]][pos_vec[hit]]
  out
}

# Same idea as band_lookup() above, but for a single scalar index -- used on
# the Modeling Choices tabs, where the "starting enrollment" and "change in
# enrollment" sliders now allow 0. R's normal vector indexing (vec[0])
# silently returns an empty (length-0) vector rather than an error, which
# then breaks every downstream calculation that reads it; this maps a 0 (or
# negative) index to a literal 0 instead, matching "$0 spent before any
# students have arrived."
idx_or_zero <- function(vec, n) if (n <= 0) 0 else vec[n]

###############################################################################
# "7. Assessing Model Fit" tab support.
#
# For a fixed seed (1) and district enrollment (10,000), what does a
# "typical" filled school of each type actually look like? Computed once,
# here, at load time (rather than as a reactive), since it's a fixed
# illustrative baseline for the tab's narrative, not something the user
# adjusts. simulate_multi_elem()/simulate_multi_secondary() already run a
# real, order-respecting bin-packing of students into buildings -- not a
# closed-form approximation -- so a "filled" building's actual population
# can land a bit under its theoretical max (450/900/1,200) depending on how
# enrollment happened to split across grades.
###############################################################################

model_fit_seed <- 1
model_fit_n <- 10000

set.seed(model_fit_seed)
model_fit_draws <- sample(grade_levels, model_fit_n, replace = TRUE)

model_fit_elem_trace <- simulate_multi_elem(model_fit_draws[
  model_fit_draws %in% elem_grades
])
model_fit_mid_trace <- simulate_multi_secondary(
  model_fit_draws[model_fit_draws %in% middle_grades],
  middle_grades,
  middle_classrooms_per_school
)
model_fit_high_trace <- simulate_multi_secondary(
  model_fit_draws[model_fit_draws %in% high_grades],
  high_grades,
  high_classrooms_per_school
)

# Average population and average teacher count across every CLOSED building
# in a band's trace -- i.e. every school except the last one, which is still
# in the process of filling up and hasn't reached capacity yet.
filled_school_stats <- function(trace) {
  n <- nrow(trace)
  if (n == 0) {
    return(list(
      avg_students = NA_real_,
      avg_teachers = NA_real_,
      n_filled = 0L
    ))
  }

  starts <- which(diff(c(0L, trace$schools)) > 0)
  ends <- c(starts[-1] - 1L, n)
  pop <- ends - starts + 1L
  teach_before <- c(0L, trace$teachers[starts[-1] - 1L])
  teachers <- trace$teachers[ends] - teach_before

  n_schools <- length(starts)
  if (n_schools < 2) {
    return(list(
      avg_students = NA_real_,
      avg_teachers = NA_real_,
      n_filled = 0L
    ))
  }

  filled_idx <- seq_len(n_schools - 1)
  list(
    avg_students = mean(pop[filled_idx]),
    avg_teachers = mean(teachers[filled_idx]),
    n_filled = length(filled_idx)
  )
}

model_fit_elem_stats <- filled_school_stats(model_fit_elem_trace)
model_fit_mid_stats <- filled_school_stats(model_fit_mid_trace)
model_fit_high_stats <- filled_school_stats(model_fit_high_trace)

###############################################################################
# The "overfit" model itself: every cost (Building, Teachers, Supplies) is
# treated as fully Variable, but Building and Teacher capacities use the
# CALCULATED averages from the actual filled schools above (rather than the
# textbook 450/900/1,200-student, 25-student-per-teacher assumptions used
# elsewhere in the app). Since everything is Variable, the model collapses
# to a single blended $/student rate per band -- exactly like choosing
# "Variable" for every cost on tabs 5/6 -- weighted by each band's share of
# the district's 13 grade levels, since that's the model's best guess at how
# any given batch of new students will split across elementary/middle/high.
###############################################################################

model_fit_elem_teacher_capacity <- model_fit_elem_stats$avg_students /
  model_fit_elem_stats$avg_teachers
model_fit_mid_teacher_capacity <- model_fit_mid_stats$avg_students /
  model_fit_mid_stats$avg_teachers
model_fit_high_teacher_capacity <- model_fit_high_stats$avg_students /
  model_fit_high_stats$avg_teachers

model_fit_elem_rate <- school_cost /
  model_fit_elem_stats$avg_students +
  teacher_cost / model_fit_elem_teacher_capacity +
  supply_rate
model_fit_mid_rate <- school_cost /
  model_fit_mid_stats$avg_students +
  teacher_cost / model_fit_mid_teacher_capacity +
  supply_rate
model_fit_high_rate <- school_cost /
  model_fit_high_stats$avg_students +
  teacher_cost / model_fit_high_teacher_capacity +
  supply_rate

model_fit_elem_frac <- length(elem_grades) / length(grade_levels)
model_fit_mid_frac <- length(middle_grades) / length(grade_levels)
model_fit_high_frac <- length(high_grades) / length(grade_levels)

model_fit_blended_rate <- model_fit_elem_frac *
  model_fit_elem_rate +
  model_fit_mid_frac * model_fit_mid_rate +
  model_fit_high_frac * model_fit_high_rate

model_fit_growth_scenarios <- c(100, 1000, 3000, 6000)
model_fit_scenario_labels <- paste0(
  "+",
  format(model_fit_growth_scenarios, big.mark = ",", trim = TRUE),
  " students"
)

###############################################################################
# Building- and Teacher-expense versions of the "overfit" model: isolate
# just the Building (and separately, Teacher) cost component of the
# blended linear model (school_cost / avg. capacity, and teacher_cost /
# avg. students-per-teacher, weighted by each band's share of the
# district's grade levels, using seed 1's calculated capacities from
# above), and compare each predicted INCREASE for a given growth scenario
# against the ACTUAL increase realized across 1,000 independently-
# simulated growth patterns.
#
# The first 10,000 students always arrive in seed 2's order
# (model_fit_mc_base_draws) -- a fixed, known starting point that's
# independent of the seed-1 draw the model's capacities were built from.
# For each of 1,000 seeds (3-1002), only the INCREMENTAL 100/1,000/3,000/
# 5,000 students on top of those first 10,000 are independently simulated,
# so each seed represents one plausible way the district's NEXT batch of
# students could arrive, continuing on from the same known starting point.
# The increase in expense from 10,000 to each target is therefore the
# marginal cost of that seed's own particular growth pattern layered onto
# the shared base -- across 1,000 seeds it traces out a real distribution
# of plausible outcomes to compare the model's single predicted number
# against.
#
# Building and Teacher costs are computed together in a single pass per
# seed (since both come from the same underlying school/teacher trace),
# to avoid doubling the most expensive thing this app computes at load
# time (1,000+ independent simulations). The user can't change any of its
# inputs from the UI -- so the result is cached to disk the first time it
# runs, keyed on the parameters that would actually change it, and reused
# (near-instantly) on every subsequent app launch until one of those
# parameters changes.
###############################################################################

model_fit_elem_building_rate <- school_cost / model_fit_elem_stats$avg_students
model_fit_mid_building_rate <- school_cost / model_fit_mid_stats$avg_students
model_fit_high_building_rate <- school_cost / model_fit_high_stats$avg_students

model_fit_blended_building_rate <- model_fit_elem_frac *
  model_fit_elem_building_rate +
  model_fit_mid_frac * model_fit_mid_building_rate +
  model_fit_high_frac * model_fit_high_building_rate

model_fit_building_predicted <- setNames(
  model_fit_blended_building_rate * model_fit_growth_scenarios,
  model_fit_scenario_labels
)

# "District students needed to fill one school" per band -- same quantity
# shown in the "district students to fill one school" table column above,
# used again below as the discrete-step threshold in the final model.
model_fit_elem_threshold <- model_fit_elem_stats$avg_students /
  model_fit_elem_frac
model_fit_mid_threshold <- model_fit_mid_stats$avg_students / model_fit_mid_frac
model_fit_high_threshold <- model_fit_high_stats$avg_students /
  model_fit_high_frac

model_fit_elem_teacher_rate <- teacher_cost / model_fit_elem_teacher_capacity
model_fit_mid_teacher_rate <- teacher_cost / model_fit_mid_teacher_capacity
model_fit_high_teacher_rate <- teacher_cost / model_fit_high_teacher_capacity

model_fit_blended_teacher_rate <- model_fit_elem_frac *
  model_fit_elem_teacher_rate +
  model_fit_mid_frac * model_fit_mid_teacher_rate +
  model_fit_high_frac * model_fit_high_teacher_rate

model_fit_teacher_predicted <- setNames(
  model_fit_blended_teacher_rate * model_fit_growth_scenarios,
  model_fit_scenario_labels
)

model_fit_mc_base_seed <- 2
set.seed(model_fit_mc_base_seed)
model_fit_mc_base_draws <- sample(grade_levels, model_fit_n, replace = TRUE)

model_fit_component_costs_from_draws <- function(draws, targets) {
  ind <- sapply(grade_levels, function(g) as.integer(draws == g))
  cum_counts <- apply(ind, 2, cumsum)
  colnames(cum_counts) <- grade_levels

  elem_pos_vec <- rowSums(cum_counts[, elem_grades, drop = FALSE])
  mid_pos_vec <- rowSums(cum_counts[, middle_grades, drop = FALSE])
  high_pos_vec <- rowSums(cum_counts[, high_grades, drop = FALSE])

  elem_trace <- simulate_multi_elem(draws[draws %in% elem_grades])
  mid_trace <- simulate_multi_secondary(
    draws[draws %in% middle_grades],
    middle_grades,
    middle_classrooms_per_school
  )
  high_trace <- simulate_multi_secondary(
    draws[draws %in% high_grades],
    high_grades,
    high_classrooms_per_school
  )

  total_schools_vec <- band_lookup(elem_trace, elem_pos_vec, "schools") +
    band_lookup(mid_trace, mid_pos_vec, "schools") +
    band_lookup(high_trace, high_pos_vec, "schools")
  total_teachers_vec <- band_lookup(elem_trace, elem_pos_vec, "teachers") +
    band_lookup(mid_trace, mid_pos_vec, "teachers") +
    band_lookup(high_trace, high_pos_vec, "teachers")

  list(
    building = (total_schools_vec * school_cost)[targets],
    teacher = (total_teachers_vec * teacher_cost)[targets]
  )
}

# Monte Carlo seeds (3-1002): the first 10,000 students are always
# model_fit_mc_base_draws (seed 2, fixed); only the incremental students on
# top of that shared base are drawn from the given tail_seed.
model_fit_component_cost_at_tail <- function(tail_seed, targets) {
  max_n <- max(targets)
  tail_n <- max_n - model_fit_n
  set.seed(tail_seed)
  tail_draws <- if (tail_n > 0) {
    sample(grade_levels, tail_n, replace = TRUE)
  } else {
    character(0)
  }
  draws <- c(model_fit_mc_base_draws, tail_draws)
  model_fit_component_costs_from_draws(draws, targets)
}

model_fit_target_n <- 10000 + c(0, model_fit_growth_scenarios)
model_fit_seeds <- 3:1002

model_fit_cache_file <- "model_fit_cache.rds"
model_fit_cache_key <- list(
  seeds = model_fit_seeds,
  target_n = model_fit_target_n,
  scenarios = model_fit_growth_scenarios,
  base_seed = model_fit_mc_base_seed,
  base_n = model_fit_n,
  metric = "building_teacher"
)

model_fit_cached <- if (file.exists(model_fit_cache_file)) {
  tryCatch(readRDS(model_fit_cache_file), error = function(e) NULL)
} else {
  NULL
}

if (
  !is.null(model_fit_cached) &&
    identical(model_fit_cached$key, model_fit_cache_key)
) {
  model_fit_actual_building_costs <- model_fit_cached$actual_building_costs
  model_fit_actual_teacher_costs <- model_fit_cached$actual_teacher_costs
} else {
  model_fit_component_results <- lapply(model_fit_seeds, function(s) {
    model_fit_component_cost_at_tail(s, model_fit_target_n)
  })
  model_fit_actual_building_costs <- t(sapply(
    model_fit_component_results,
    function(r) r$building
  ))
  model_fit_actual_teacher_costs <- t(sapply(
    model_fit_component_results,
    function(r) r$teacher
  ))
  colnames(model_fit_actual_building_costs) <- c(
    "base",
    model_fit_scenario_labels
  )
  colnames(model_fit_actual_teacher_costs) <- c(
    "base",
    model_fit_scenario_labels
  )

  tryCatch(
    saveRDS(
      list(
        key = model_fit_cache_key,
        actual_building_costs = model_fit_actual_building_costs,
        actual_teacher_costs = model_fit_actual_teacher_costs
      ),
      model_fit_cache_file
    ),
    error = function(e) NULL # read-only working directory, etc. -- just skip caching
  )
}

model_fit_actual_building_increases <- model_fit_actual_building_costs[,
  -1,
  drop = FALSE
] -
  model_fit_actual_building_costs[, "base"]
colnames(model_fit_actual_building_increases) <- model_fit_scenario_labels

model_fit_actual_teacher_increases <- model_fit_actual_teacher_costs[,
  -1,
  drop = FALSE
] -
  model_fit_actual_teacher_costs[, "base"]
colnames(model_fit_actual_teacher_increases) <- model_fit_scenario_labels

model_fit_building_hist_data <- rbindlist(lapply(
  model_fit_scenario_labels,
  function(nm) {
    data.table(
      scenario = nm,
      increase = model_fit_actual_building_increases[, nm]
    )
  }
))
model_fit_building_hist_data[,
  scenario := factor(scenario, levels = model_fit_scenario_labels)
]

model_fit_teacher_hist_data <- rbindlist(lapply(
  model_fit_scenario_labels,
  function(nm) {
    data.table(
      scenario = nm,
      increase = model_fit_actual_teacher_increases[, nm]
    )
  }
))
model_fit_teacher_hist_data[,
  scenario := factor(scenario, levels = model_fit_scenario_labels)
]

model_fit_building_pred_lines <- data.table(
  scenario = factor(
    names(model_fit_building_predicted),
    levels = model_fit_scenario_labels
  ),
  predicted = as.numeric(model_fit_building_predicted)
)

model_fit_teacher_pred_lines <- data.table(
  scenario = factor(
    names(model_fit_teacher_predicted),
    levels = model_fit_scenario_labels
  ),
  predicted = as.numeric(model_fit_teacher_predicted)
)

model_fit_building_summary_table <- data.table(
  scenario = model_fit_scenario_labels,
  modeled = as.numeric(model_fit_building_predicted),
  actual_mean = colMeans(model_fit_actual_building_increases),
  actual_median = apply(model_fit_actual_building_increases, 2, median),
  actual_sd = apply(model_fit_actual_building_increases, 2, sd)
)

model_fit_teacher_summary_table <- data.table(
  scenario = model_fit_scenario_labels,
  modeled = as.numeric(model_fit_teacher_predicted),
  actual_mean = colMeans(model_fit_actual_teacher_increases),
  actual_median = apply(model_fit_actual_teacher_increases, 2, median),
  actual_sd = apply(model_fit_actual_teacher_increases, 2, sd)
)

# Combined Building + Teacher dataset for a single 2 (metric) x 4 (scenario)
# grid of histograms -- Building expense on the top row, Teacher expense on
# the bottom row, so the two are directly comparable side by side.
model_fit_metric_levels <- c("Building Expense", "Teacher Expense")

model_fit_combined_hist_data <- rbindlist(list(
  copy(model_fit_building_hist_data)[, metric := "Building Expense"],
  copy(model_fit_teacher_hist_data)[, metric := "Teacher Expense"]
))
model_fit_combined_hist_data[,
  metric := factor(metric, levels = model_fit_metric_levels)
]

model_fit_combined_pred_lines <- rbindlist(list(
  copy(model_fit_building_pred_lines)[, metric := "Building Expense"],
  copy(model_fit_teacher_pred_lines)[, metric := "Teacher Expense"]
))
model_fit_combined_pred_lines[,
  metric := factor(metric, levels = model_fit_metric_levels)
]

# ---- Michigan Ross styling ---------------------------------------------------
# Brand colors per rossweb.bus.umich.edu/style-guide: PMS 282 blue (#00274C)
# and PMS 7406 maize (#FFCB05). Ross uses Open Sans for web/digital content.
ross_head <- tags$head(
  tags$link(
    rel = "stylesheet",
    href = "https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&display=swap"
  ),
  tags$style(HTML(
    "
    body { font-family: 'Open Sans', sans-serif; color: #1a1a1a; }
    h1, h2, h3, h4, h5 { font-family: 'Open Sans', sans-serif; color: #00274C; font-weight: 700; }

    .navbar-inverse { background-color: #00274C; border-color: #00274C; }
    .navbar-inverse .navbar-brand { color: #FFCB05 !important; font-weight: 700; }
    .navbar-inverse .navbar-nav > li > a { color: #ffffff !important; }
    .navbar-inverse .navbar-nav > li > a:hover { background-color: #17497a !important; color: #FFCB05 !important; }
    .navbar-inverse .navbar-nav > .active > a,
    .navbar-inverse .navbar-nav > .active > a:hover,
    .navbar-inverse .navbar-nav > .active > a:focus {
      background-color: #FFCB05 !important; color: #00274C !important; font-weight: 700;
    }

    .btn, .btn-default { background-color: #00274C; color: #ffffff; border: none; }
    .btn:hover, .btn-default:hover { background-color: #FFCB05; color: #00274C; }

    .case-banner { background-color: #00274C; color: #ffffff; padding: 32px 28px; margin: -15px -15px 24px -15px; }
    .case-banner h1 { color: #FFCB05; margin-bottom: 4px; }
    .case-banner h3 { color: #ffffff; font-weight: 400; margin-top: 0; }

    .param-table { width: 100%; table-layout: fixed; border-collapse: collapse; margin-bottom: 20px; }
    .param-table th { background-color: #00274C; color: #ffffff; text-align: left; padding: 8px 12px; }
    .param-table td { padding: 8px 12px; border-bottom: 1px solid #ddd; }
    .param-table tr:nth-child(even) { background-color: #f5f6f8; }

    .cost-card { border-left: 6px solid #FFCB05; background-color: #f5f6f8; padding: 12px 18px; margin-bottom: 10px; }
    .situation-card { border-left: 6px solid #00274C; background-color: #fff9e0; padding: 16px 20px; margin-top: 16px; }
    .instruction-banner { border-left: 6px solid #FFCB05; background-color: #eef3f7; color: #00274C; font-weight: 600; font-size: 15px; padding: 12px 18px; margin-bottom: 14px; }
  "
  ))
)

# ---- UI ---------------------------------------------------------------------
ui <- navbarPage(
  title = NULL,
  header = ross_head,
  inverse = TRUE,

  tabPanel(
    "1. Background",
    fluidPage(
      div(
        class = "case-banner",
        h1("Leadersville Public School District"),
        h3("Choosing the Right Cost Model")
      ),

      div(
        h4("Background"),
        p(
          "Leadersville Public School District is a large K-12 public school district in ",
          "Leadersville, Michigan. The district runs three types of schools: elementary ",
          "schools (grades K-5), middle schools (grades 6-8), and high schools ",
          "(grades 9-12)."
        ),
        p(
          "Elementary schools are organized in self-contained classrooms: one teacher ",
          "runs a single classroom for a single grade, all day. Middle and high schools ",
          "are organized around students taking subject classes during a class period. ",
          "There are 6 class periods in a day and each student takes the same six ",
          "subjects: English, Science, Math, Foreign Language, History, and Specials. ",
          "Middle and high school teachers only teach one subject, but they can teach ",
          "up to 6 class periods per day of that subject."
        ),

        tags$table(
          class = "param-table",
          tags$colgroup(
            tags$col(style = "width: 34%;"),
            tags$col(style = "width: 22%;"),
            tags$col(style = "width: 22%;"),
            tags$col(style = "width: 22%;")
          ),
          tags$tr(
            tags$th("Parameter"),
            tags$th("Elementary (K-5)"),
            tags$th("Middle (6-8)"),
            tags$th("High (9-12)")
          ),
          tags$tr(
            tags$td("Staffing model"),
            tags$td("Self-contained classroom teacher"),
            tags$td("Subject teachers"),
            tags$td("Subject teachers")
          ),
          tags$tr(
            tags$td("Max students per classroom / section"),
            tags$td("25"),
            tags$td("25"),
            tags$td("25")
          ),
          tags$tr(
            tags$td("Classrooms per school"),
            tags$td("Max 3 per grade (18 total)"),
            tags$td("36"),
            tags$td("48")
          ),
          tags$tr(
            tags$td("Subjects taught"),
            tags$td("—"),
            tags$td(
              "6 (English, Science, Math, Foreign Language, History, Specials)"
            ),
            tags$td("6 (same as Middle)")
          ),
          tags$tr(
            tags$td("Classes taught per teacher per day"),
            tags$td("1 (own classroom)"),
            tags$td("6"),
            tags$td("6")
          ),
          tags$tr(
            tags$td("Max students per teacher"),
            tags$td("25"),
            tags$td("150 (6 sections × 25)"),
            tags$td("150 (6 sections × 25)")
          ),
          tags$tr(
            tags$td(tags$b("Max students per school building")),
            tags$td(tags$b("450 (3 rooms × 25 × 6 grades)")),
            tags$td(tags$b("900 (6 teachers/subject × 150)")),
            tags$td(tags$b("1,200 (8 teachers/subject × 150)"))
          )
        ),

        h4("Cost Components"),
        p(
          "For simplicity, let's assume that Leadersville only incurs three costs:"
        ),
        div(
          class = "cost-card",
          HTML(
            "<b>Building expense:</b> $1,500,000 per school building, per year, regardless of school type"
          )
        ),
        div(
          class = "cost-card",
          HTML(
            "<b>Teacher salaries:</b> $80,000 per teacher, per year, regardless of teacher type"
          )
        ),
        div(
          class = "cost-card",
          HTML(
            "<b>School supplies:</b> $1,000 per student, per year, regardless of student type"
          )
        ),

        h4(
          style = "margin-top: 24px;",
          "Understanding the Cost Implications of Tappan Farms"
        ),
        div(
          class = "situation-card",
          p(
            "Tappan Farms is a new housing development nearing completion within ",
            "Leadersville's boundaries, and district leadership is trying to understand ",
            "the cost implications of the influx of new students."
          ),
          p(HTML(paste0(
            "The district CFO expects the housing development will increase total ",
            "enrollment in the district by roughly <b>1,000 students</b>."
          ))),
          p(HTML(paste0(
            "One of the high school principals believes her school specifically will ",
            "receive roughly <b>50 new students</b>."
          )))
        ),

        h4(style = "margin-top: 20px;", "Your Task"),
        p(
          "Think through how you might tackle this problem, and in the space below, ",
          "briefly reflect on the following questions:"
        ),
        tags$ul(
          tags$li("What would your cost model look like?"),
          tags$li(
            "Would you make different choices if you were the district CFO or ",
            "the high school principal?"
          ),
          tags$li(
            "How confident would you be in your answer, and what would be the ",
            "major reasons why your predictions for how costs would change may ",
            "be erroneous?"
          )
        ),
        textAreaInput(
          "reflection_notes",
          label = NULL,
          placeholder = "Jot down your initial thoughts here...",
          width = "100%",
          rows = 6
        ),
        p(
          "You don't have to build a model by yourself just yet, but if you're eager ",
          "to start trying, go right ahead! Once you're ready, head to the tabs above ",
          "and start exploring."
        )
      )
    )
  ),

  tabPanel(
    "2. Elementary",
    fluidPage(
      h4("Understanding Cost Growth at an Elementary School"),
      p(
        "This tab shows the costs for single elementary school as enrollment grows. ",
        "Students are enrolled in the order they arrive, and while students are drawn ",
        "from a uniform random distribution (i.e., the next student is equally likely to ",
        "be from any grade), they may not arrive evenly across grades. Since an ",
        "elementary school has at most 3 classrooms per grade, the school stops admitting ",
        "students once a grade reaches 75 students. This typically happens before the ",
        "theoretical maximum of 450 students because of the uneven student arrivals."
      ),

      fluidRow(
        column(
          width = 8,
          div(
            class = "instruction-banner",
            "Click the highlighted ovals for details of what's driving the cost ",
            "increases in that panel -- explanations appear in the column to the right."
          ),
          plotOutput("elemCostPlot", height = "900px", click = "elemPlotClick")
        ),
        column(
          width = 4,
          uiOutput("elemNotesColumn")
        )
      ),
      htmlOutput("elemCostSummary"),
      wellPanel(
        numericInput(
          "rand_seed_elem",
          "Random Seed",
          value = 1,
          min = 1,
          step = 1
        ),
        helpText(
          "Change the Random Seed to view the implications of students ",
          "arriving in a different order."
        ),
        actionButton("generate_body_elem", "Refresh", width = "100%")
      )
    )
  ),

  tabPanel(
    "3. High School",
    fluidPage(
      h4("Understanding Cost Growth at a High School"),
      p(
        "This tab shows how the costs of operating a high school increase with enrollment ",
        "(again enrolling grade 9-12 students in the order they arrive). Each student ",
        "takes the same six subjects, so when the school needs to add classes, it hires ",
        "six teachers all at once—one per subject. Because each class is grade-specific ",
        "(i.e., a 9th grader can't take 11th-grade English) and each teacher can only ",
        "teach 6 classes, the \"steps\" where teachers are hired are not uniform in width. ",
        "That is, the grade order of arriving students determines exactly when we need to ",
        "add another set of classes. The school stops accepting students when each ",
        "classroom in the building is occupied by a teacher, and the next student cannot ",
        "be accommodated because all classes in that grade are full. Because of uneven ",
        "grade arrivals, the school will be \"full\" before it reaches the theoretical ",
        "maximum capacity of 1,200 students."
      ),

      fluidRow(
        column(
          width = 8,
          div(
            class = "instruction-banner",
            "Click the highlighted ovals for details of what's driving the cost ",
            "increases in that panel -- explanations appear in the column to the right."
          ),
          plotOutput("highCostPlot", height = "900px", click = "highPlotClick")
        ),
        column(
          width = 4,
          uiOutput("highNotesColumn")
        )
      ),
      htmlOutput("highCostSummary"),
      wellPanel(
        numericInput(
          "rand_seed_high",
          "Random Seed",
          value = 1,
          min = 1,
          step = 1
        ),
        helpText(
          "Change the Random Seed to view the implications of students ",
          "arriving in a different order."
        ),
        actionButton("generate_body_high", "Refresh", width = "100%")
      )
    )
  ),

  tabPanel(
    "4. District",
    fluidPage(
      h4("Understanding Cost Growth across the District"),
      p(
        "This tab reports costs for the district as a whole as more students enroll. It ",
        "assumes that the district opens a new school whenever the corresponding school ",
        "type fills up. For simplicity, it does not take into account anything about the ",
        "geographical locations of schools. That is, there is no concept of a ",
        "\"neighborhood school\" where students attend their closest school; instead, ",
        "students are assigned to the \"newest\" (most recently opened) school, as that ",
        "school will have capacity to enroll them."
      ),

      fluidRow(
        column(
          width = 8,
          div(
            class = "instruction-banner",
            "Click the highlighted ovals for details of what's driving the cost ",
            "increases in that panel -- explanations appear in the column to the right."
          ),
          plotOutput(
            "districtCostPlot",
            height = "900px",
            click = "districtPlotClick"
          )
        ),
        column(
          width = 4,
          uiOutput("districtNotesColumn")
        )
      ),
      htmlOutput("districtCostSummary"),
      wellPanel(
        numericInput(
          "district_seed",
          "Random Seed",
          value = 1,
          min = 1,
          step = 1
        ),
        sliderInput(
          "district_range",
          "Student range (minimum - maximum)",
          min = 0,
          max = 20000,
          value = c(0, 20000),
          step = 100
        ),
        helpText(
          "Drag either handle to set the minimum and maximum -- the minimum ",
          "can never be dragged past the maximum, or vice versa."
        ),
        helpText(
          "Change the Random Seed to view the implications of students ",
          "arriving in a different order."
        ),
        actionButton("district_run", "Trace District Costs", width = "100%")
      )
    )
  ),

  tabPanel(
    "5. Modeling Choices: High School",
    fluidPage(
      h4("Modeling Costs as Fixed or Variable"),
      p(
        "The high school's true cost follows a complicated curve resembling a sloped ",
        "staircase. Complicated cost curves are hard to deal with, so let's build a linear ",
        "model to make our estimates easier. Play with the parameters to the model on the ",
        "right (fixed/variable, per unit costs, section capacity) to get a sense of how ",
        "model fit changes with different choices. Once you're ready, answer the reflection ",
        "questions below."
      ),

      fluidRow(
        column(
          width = 8,
          plotOutput("modelChoicePlot", height = "500px"),
          htmlOutput("modelChoiceStats"),
          hr(),
          h5("Reflection Questions"),
          p(
            strong("1.)"),
            " For estimating the cost increase associated with an additional 50 ",
            "students enrolled in the high school, what parameters (fixed/variable, cost per ",
            "school/student/teacher, students per section) produce the best model? Why?"
          ),
          textAreaInput(
            "mc_q1_answer",
            label = NULL,
            placeholder = "Type your answer here...",
            rows = 4,
            width = "100%"
          ),
          p(
            strong("2.)"),
            " Try changing the random seed from 1 to 7 (click the refresh button ",
            "to generate a new curve). What changed? Does that change your answer to the prior ",
            "question?"
          ),
          textAreaInput(
            "mc_q2_answer",
            label = NULL,
            placeholder = "Type your answer here...",
            rows = 4,
            width = "100%"
          ),
          p(
            strong("3.)"),
            " Go back to seed 1 but change the starting enrollment to 300 and the ",
            "change in enrollment to 600. What model would you use now?"
          ),
          textAreaInput(
            "mc_q3_answer",
            label = NULL,
            placeholder = "Type your answer here...",
            rows = 4,
            width = "100%"
          ),
          p(
            strong("4.)"),
            " The high school principal decided to model her school's costs as ",
            "follows:"
          ),
          tags$ul(
            tags$li("Building expense, Fixed ($1,500,000/building)"),
            tags$li("Teachers, Variable ($80,000/teacher)"),
            tags$li("Supplies, Variable ($1,000/student)"),
            tags$li("25 students/section")
          ),
          p(
            "However, she noticed that every year, no matter the school's enrollment, actual ",
            "costs were higher than the model. What's the reason for the discrepancy?"
          ),
          textAreaInput(
            "mc_q4_answer",
            label = NULL,
            placeholder = "Type your answer here...",
            rows = 4,
            width = "100%"
          ),
          p(
            strong("5.)"),
            " To fix the underestimation, the principal decided to change her ",
            "model to having a max number of 15 students/section. Will that fix the problem? ",
            "Why or why not?"
          ),
          textAreaInput(
            "mc_q5_answer",
            label = NULL,
            placeholder = "Type your answer here...",
            rows = 4,
            width = "100%"
          )
        ),
        column(
          width = 4,
          wellPanel(
            actionButton(
              "mc_reset_defaults",
              "Reset Defaults",
              width = "100%",
              class = "btn-warning"
            ),
            hr(),
            sliderInput(
              "mc_start",
              "Starting enrollment (students)",
              min = 0,
              max = 1195,
              value = 725,
              step = 1
            ),
            sliderInput(
              "mc_delta",
              "Change in enrollment (students)",
              min = -725,
              max = 470,
              value = 50,
              step = 1
            ),
            helpText(
              "This slider's range adjusts automatically so the ending enrollment ",
              "always stays between 0 and the full enrollment the current draw ",
              "admits. Negative values mean a decrease in enrollment."
            ),
            hr(),
            h5("Cost assumptions"),
            helpText(
              "Defaults match the case. Change any of these to see how ",
              "your model responds to different cost assumptions."
            ),
            numericInput(
              "mc_school_cost",
              "Building cost per school ($)",
              value = school_cost,
              min = 0,
              step = 50000
            ),
            numericInput(
              "mc_supply_rate",
              "Supply cost per student ($)",
              value = supply_rate,
              min = 0,
              step = 50
            ),
            numericInput(
              "mc_teacher_cost",
              "Teacher cost per teacher ($)",
              value = teacher_cost,
              min = 0,
              step = 1000
            ),
            numericInput(
              "mc_teacher_capacity",
              "Max students per section (per teacher)",
              value = teacher_capacity,
              min = 1,
              step = 1
            ),
            hr(),
            h5("Classify each cost"),
            radioButtons(
              "mc_building_choice",
              "Building",
              choices = c("Fixed", "Variable"),
              selected = "Variable",
              inline = TRUE
            ),
            radioButtons(
              "mc_supplies_choice",
              "Supplies",
              choices = c("Fixed", "Variable"),
              selected = "Variable",
              inline = TRUE
            ),
            radioButtons(
              "mc_teacher_choice",
              "Teachers",
              choices = c("Fixed", "Variable"),
              selected = "Variable",
              inline = TRUE
            ),
            hr(),
            numericInput(
              "rand_seed_high_mc",
              "Random Seed",
              value = 1,
              min = 1,
              step = 1
            ),
            helpText(
              "Change the Random Seed to view the implications of students ",
              "arriving in a different order. This shares the same underlying ",
              "random draw as the \"3. High School\" tab."
            ),
            actionButton("generate_body_high_mc", "Refresh", width = "100%")
          )
        )
      )
    )
  ),

  tabPanel(
    "6. Modeling Choices: District",
    fluidPage(
      h4("Modeling District-Wide Costs as Fixed or Variable"),
      p(
        "The district's true cost follows an even more complicated staircase than a single ",
        "high school's, because elementary, middle, and high schools are all opening and ",
        "hiring teachers at their own pace as enrollment grows district-wide. Let's build a ",
        "linear model to make our estimates easier. Play with the parameters to the model on ",
        "the right (fixed/variable, per unit costs, section capacity) to get a sense of how ",
        "model fit changes with different choices. Be sure to experiment with different ",
        "ranges for the plot view to zoom in or out on different parts of the cost curve. ",
        "Once you've had a chance to experiment, scroll down and answer the reflection ",
        "questions."
      ),

      fluidRow(
        column(
          width = 8,
          plotOutput("modelChoicePlotDistrict", height = "500px"),
          htmlOutput("modelChoiceStatsDistrict"),
          hr(),
          h5("Reflection Questions"),
          p(
            strong("1.)"),
            " For modeling a 1,000 student increase, does it make sense to treat ",
            "school buildings as fully variable or does this oversimplify things? What if the ",
            "district were modeling an increase of 100 students? 3,000 students?"
          ),
          textAreaInput(
            "mc2_q1_answer",
            label = NULL,
            placeholder = "Type your answer here...",
            rows = 4,
            width = "100%"
          ),
          p(
            strong("2.)"),
            " If you select schools as variable, you'll see in the Variable ",
            "costs breakdown the cost per school divided by a blended average capacity. What ",
            "does this number mean and where do you think this number is coming from? Does ",
            "using this blended capacity make sense? When would it and when would it not?"
          ),
          textAreaInput(
            "mc2_q2_answer",
            label = NULL,
            placeholder = "Type your answer here...",
            rows = 4,
            width = "100%"
          ),
          p(
            strong("3.)"),
            " If you treat everything as variable and keep the default values, ",
            "the modeled cost curve is always below the real cost curve and shallower (it ",
            "grows at a slower rate). Why is this the case? Is that a problem? How would you ",
            "adjust things in response?"
          ),
          textAreaInput(
            "mc2_q3_answer",
            label = NULL,
            placeholder = "Type your answer here...",
            rows = 4,
            width = "100%"
          )
        ),
        column(
          width = 4,
          wellPanel(
            actionButton(
              "mc2_reset_defaults",
              "Reset Defaults",
              width = "100%",
              class = "btn-warning"
            ),
            hr(),
            sliderInput(
              "mc2_start",
              "Starting enrollment (students)",
              min = 0,
              max = 19999,
              value = 10000,
              step = 1
            ),
            sliderInput(
              "mc2_delta",
              "Change in enrollment (students)",
              min = -10000,
              max = 10000,
              value = 1000,
              step = 1
            ),
            helpText(
              "This slider's range adjusts automatically so the ending enrollment ",
              "always stays between 0 and the district's full traced enrollment. ",
              "Negative values mean a decrease in enrollment."
            ),
            hr(),
            h5("Plot view"),
            sliderInput(
              "mc2_view_range",
              "Enrollment range shown on graph (students)",
              min = 0,
              max = district_mc_max_n,
              value = c(7000, 12000),
              step = 100
            ),
            helpText(
              "Widen this out (up to the full 0-20,000 range) to see more of the ",
              "district's cost curve at once."
            ),
            hr(),
            h5("Cost assumptions"),
            helpText(
              "Defaults match the case. Change any of these to see how ",
              "your model responds to different cost assumptions."
            ),
            numericInput(
              "mc2_school_cost",
              "Building cost per school ($)",
              value = school_cost,
              min = 0,
              step = 50000
            ),
            numericInput(
              "mc2_supply_rate",
              "Supply cost per student ($)",
              value = supply_rate,
              min = 0,
              step = 50
            ),
            numericInput(
              "mc2_teacher_cost",
              "Teacher cost per teacher ($)",
              value = teacher_cost,
              min = 0,
              step = 1000
            ),
            numericInput(
              "mc2_teacher_capacity",
              "Max students per section (middle/high, per teacher)",
              value = teacher_capacity,
              min = 1,
              step = 1
            ),
            numericInput(
              "mc2_elem_teacher_capacity",
              "Max students per elementary school teacher",
              value = teacher_capacity,
              min = 1,
              step = 1
            ),
            numericInput(
              "mc2_elem_school_capacity",
              "Maximum students per elementary school",
              value = elem_classrooms_per_grade_cap *
                teacher_capacity *
                length(elem_grades),
              min = 1,
              step = 10
            ),
            numericInput(
              "mc2_mid_school_capacity",
              "Maximum students per middle school",
              value = middle_capacity_per_school,
              min = 1,
              step = 10
            ),
            numericInput(
              "mc2_high_school_capacity",
              "Maximum students per high school",
              value = high_capacity_per_school,
              min = 1,
              step = 10
            ),
            hr(),
            h5("Classify each cost"),
            radioButtons(
              "mc2_building_choice",
              "Building",
              choices = c("Fixed", "Variable"),
              selected = "Variable",
              inline = TRUE
            ),
            radioButtons(
              "mc2_supplies_choice",
              "Supplies",
              choices = c("Fixed", "Variable"),
              selected = "Variable",
              inline = TRUE
            ),
            radioButtons(
              "mc2_teacher_choice",
              "Teachers",
              choices = c("Fixed", "Variable"),
              selected = "Variable",
              inline = TRUE
            ),
            hr(),
            numericInput(
              "rand_seed_district_mc",
              "Random Seed",
              value = 1,
              min = 1,
              step = 1
            ),
            helpText(
              "Change the Random Seed to view the implications of students ",
              "arriving in a different order across the whole district."
            ),
            actionButton("generate_body_district_mc", "Refresh", width = "100%")
          )
        )
      )
    )
  ),

  tabPanel(
    "7. Assessing Model Fit",
    fluidPage(
      h4("Is a Complicated Model Better?"),

      p(
        "We've already seen (on prior tabs) that based on what ultimate question you're ",
        "trying to solve, you may make different choices about how to approximate the ",
        "underlying cost structure. On this tab, we'll explore to what extent building a ",
        "more complicated model produces better insights."
      ),

      h5(
        style = "margin-top: 20px;",
        "Should building expense be modeled as steps or is a linear approximation sufficient?"
      ),

      p(
        "We know from our understanding of cost structure that uneven arrival of students ",
        "across grades results in schools being \"filled\" below their theoretical maximum ",
        "of 450/900/1200. If we were to assume that schools could serve these student ",
        "levels, we would underestimate the number of schools we need. Thus, let's figure ",
        "out what the practical capacity is of each school based on our experience. Using ",
        "the student arrivals from random seed 1 and a district-wide enrollment of 10,000 ",
        "students, we can take the filled schools and see how many students they served on ",
        "average."
      ),

      tags$table(
        class = "param-table",
        tags$tr(
          tags$th("School type"),
          tags$th("Filled schools"),
          tags$th("Avg. students (filled schools)"),
          tags$th("Avg. teachers (filled schools)"),
          tags$th("Avg. students per teacher (filled schools)")
        ),
        tags$tr(
          tags$td("Elementary"),
          tags$td(model_fit_elem_stats$n_filled),
          tags$td(format(
            round(model_fit_elem_stats$avg_students),
            big.mark = ","
          )),
          tags$td(format(
            round(model_fit_elem_stats$avg_teachers, 1),
            big.mark = ",",
            nsmall = 1
          )),
          tags$td(format(
            round(model_fit_elem_teacher_capacity, 1),
            big.mark = ",",
            nsmall = 1
          ))
        ),
        tags$tr(
          tags$td("Middle"),
          tags$td(model_fit_mid_stats$n_filled),
          tags$td(format(
            round(model_fit_mid_stats$avg_students),
            big.mark = ","
          )),
          tags$td(format(
            round(model_fit_mid_stats$avg_teachers, 1),
            big.mark = ",",
            nsmall = 1
          )),
          tags$td(format(
            round(model_fit_mid_teacher_capacity, 1),
            big.mark = ",",
            nsmall = 1
          ))
        ),
        tags$tr(
          tags$td("High"),
          tags$td(model_fit_high_stats$n_filled),
          tags$td(format(
            round(model_fit_high_stats$avg_students),
            big.mark = ","
          )),
          tags$td(format(
            round(model_fit_high_stats$avg_teachers, 1),
            big.mark = ",",
            nsmall = 1
          )),
          tags$td(format(
            round(model_fit_high_teacher_capacity, 1),
            big.mark = ",",
            nsmall = 1
          ))
        )
      ),

      p(
        style = "margin-top: 16px;",
        "As expected, the typical filled school is below the theoretical 450/900/1200 ",
        "student capacity. However, these are fairly large steps, so it might not make ",
        "sense to treat schools as fully variable. Let's see how wrong we would be for ",
        "various growth scenarios if we did."
      ),

      p(
        "To treat buildings as fully variable, we need to make some assumptions. We need ",
        "to assume that 6/13 (46.2%) of the arriving students are Elementary, 3/13 (23.1%) ",
        "are Middle School, and 4/13 are High School (30.7%). That means that for an ",
        "Elementary school, even though it will fill at 395 elementary students, that only ",
        "happens after 855 new students enroll in the district (395/46.2%). That means that ",
        "for each new student in the district, we need to increase our elementary school ",
        "building expense by $1,500,000/855=$1754. We can do similar calculations for ",
        "middle and high school as detailed in the table below."
      ),

      tags$table(
        class = "param-table",
        tags$tr(
          tags$th("School type"),
          tags$th("Share of new students"),
          tags$th("Avg. students/filled school"),
          tags$th("District students to fill one school"),
          tags$th("Building expense/school"),
          tags$th("Building expense/additional student")
        ),
        tags$tr(
          tags$td("Elementary"),
          tags$td(paste0(
            length(elem_grades),
            "/",
            length(grade_levels),
            " (",
            round(100 * model_fit_elem_frac, 1),
            "%)"
          )),
          tags$td(format(
            round(model_fit_elem_stats$avg_students),
            big.mark = ","
          )),
          tags$td(format(
            round(model_fit_elem_stats$avg_students / model_fit_elem_frac),
            big.mark = ","
          )),
          tags$td(paste0("$", format(school_cost, big.mark = ","))),
          tags$td(paste0(
            "$",
            format(
              round(model_fit_elem_frac * model_fit_elem_building_rate),
              big.mark = ","
            )
          ))
        ),
        tags$tr(
          tags$td("Middle"),
          tags$td(paste0(
            length(middle_grades),
            "/",
            length(grade_levels),
            " (",
            round(100 * model_fit_mid_frac, 1),
            "%)"
          )),
          tags$td(format(
            round(model_fit_mid_stats$avg_students),
            big.mark = ","
          )),
          tags$td(format(
            round(model_fit_mid_stats$avg_students / model_fit_mid_frac),
            big.mark = ","
          )),
          tags$td(paste0("$", format(school_cost, big.mark = ","))),
          tags$td(paste0(
            "$",
            format(
              round(model_fit_mid_frac * model_fit_mid_building_rate),
              big.mark = ","
            )
          ))
        ),
        tags$tr(
          tags$td("High"),
          tags$td(paste0(
            length(high_grades),
            "/",
            length(grade_levels),
            " (",
            round(100 * model_fit_high_frac, 1),
            "%)"
          )),
          tags$td(format(
            round(model_fit_high_stats$avg_students),
            big.mark = ","
          )),
          tags$td(format(
            round(model_fit_high_stats$avg_students / model_fit_high_frac),
            big.mark = ","
          )),
          tags$td(paste0("$", format(school_cost, big.mark = ","))),
          tags$td(paste0(
            "$",
            format(
              round(model_fit_high_frac * model_fit_high_building_rate),
              big.mark = ","
            )
          ))
        )
      ),

      p(
        style = "margin-top: 16px;",
        "Summing the building expense per additional student across all three school ",
        "types, the blended rate is $",
        format(round(model_fit_blended_building_rate), big.mark = ","),
        " per additional ",
        "district student."
      ),

      p(
        style = "margin-top: 16px;",
        "Now let's take a district with 10,000 students currently enrolled and simulate ",
        "1,000 different arrival patterns. For each of these patterns, see how many ",
        "buildings we'd actually need to build for 4 different growth scenarios: adding ",
        "100, 1,000, 3,000, and 6,000 students."
      ),

      div(
        class = "instruction-banner",
        "Click each graph panel for a deeper explanation."
      ),
      plotOutput(
        "modelFitBuildingHistograms",
        height = "440px",
        click = "modelFitBuildingClick"
      ),
      uiOutput("modelFitBuildingCallout"),

      p(
        style = "margin-top: 16px;",
        "Based on these results, it probably makes the most sense to model building ",
        "expense in discrete chunks of fixed costs rather than fully variable, even for ",
        "large swings in enrollment."
      ),

      h5(style = "margin-top: 20px;", "How about teachers?"),
      p(
        "Teachers also create discrete chunks of capacity, so is there value in modeling ",
        "teacher expense as a step function as well? Let's do the same exercise to see."
      ),

      p(
        "Theoretically, full classes mean 25 students per teacher. However, when schools ",
        "fill because one grade reaches capacity, the other grades' classes are not ",
        "necessarily full. We saw from the first table on this tab that for full schools, ",
        "the average number of students per class is indeed under 25. Like we did with ",
        "buildings, we can get a blended rate of teacher expense per student."
      ),

      tags$table(
        class = "param-table",
        tags$tr(
          tags$th("School type"),
          tags$th("Share of new students"),
          tags$th("Avg. students/teacher (filled schools, from table above)"),
          tags$th("Teacher expense/teacher"),
          tags$th("Teacher expense/student")
        ),
        tags$tr(
          tags$td("Elementary"),
          tags$td(paste0(
            length(elem_grades),
            "/",
            length(grade_levels),
            " (",
            round(100 * model_fit_elem_frac, 1),
            "%)"
          )),
          tags$td(format(
            round(model_fit_elem_teacher_capacity, 1),
            big.mark = ",",
            nsmall = 1
          )),
          tags$td(paste0("$", format(teacher_cost, big.mark = ","))),
          tags$td(paste0(
            "$",
            format(round(model_fit_elem_teacher_rate), big.mark = ",")
          ))
        ),
        tags$tr(
          tags$td("Middle"),
          tags$td(paste0(
            length(middle_grades),
            "/",
            length(grade_levels),
            " (",
            round(100 * model_fit_mid_frac, 1),
            "%)"
          )),
          tags$td(format(
            round(model_fit_mid_teacher_capacity, 1),
            big.mark = ",",
            nsmall = 1
          )),
          tags$td(paste0("$", format(teacher_cost, big.mark = ","))),
          tags$td(paste0(
            "$",
            format(round(model_fit_mid_teacher_rate), big.mark = ",")
          ))
        ),
        tags$tr(
          tags$td("High"),
          tags$td(paste0(
            length(high_grades),
            "/",
            length(grade_levels),
            " (",
            round(100 * model_fit_high_frac, 1),
            "%)"
          )),
          tags$td(format(
            round(model_fit_high_teacher_capacity, 1),
            big.mark = ",",
            nsmall = 1
          )),
          tags$td(paste0("$", format(teacher_cost, big.mark = ","))),
          tags$td(paste0(
            "$",
            format(round(model_fit_high_teacher_rate), big.mark = ",")
          ))
        )
      ),

      p(
        style = "margin-top: 16px;",
        "Calculating teacher cost for the average student involves calculating a blended ",
        "rate across the three student types (elementary, middle, and high). We do this ",
        "by calculating a weighted average based on the proportion of students of each ",
        "type."
      ),

      p(
        style = "margin-top: 16px; font-size: 15px;",
        "Blended rate = (",
        round(100 * model_fit_elem_frac, 1),
        "% ",
        HTML("&times;"),
        " $",
        format(round(model_fit_elem_teacher_rate), big.mark = ","),
        ") + (",
        round(100 * model_fit_mid_frac, 1),
        "% ",
        HTML("&times;"),
        " $",
        format(round(model_fit_mid_teacher_rate), big.mark = ","),
        ") + (",
        round(100 * model_fit_high_frac, 1),
        "% ",
        HTML("&times;"),
        " $",
        format(round(model_fit_high_teacher_rate), big.mark = ","),
        ") = $",
        format(round(model_fit_blended_teacher_rate), big.mark = ","),
        "/student"
      ),

      div(
        class = "instruction-banner",
        "Click each graph panel for a deeper explanation."
      ),
      plotOutput(
        "modelFitHistograms",
        height = "440px",
        click = "modelFitTeacherClick"
      ),
      uiOutput("modelFitTeacherCallout"),

      p(
        style = "margin-top: 16px;",
        "Unless we are interested in very small changes in enrollment, there's no ",
        "improvement to be gained by modeling teachers district-wide in discrete chunks ",
        "of fixed capacity. The uncertainty in the student arrival sequence and when ",
        "teachers are added makes a smooth linear approximation of teacher expense a good ",
        "way to model these costs."
      ),

      hr(),
      h4(style = "margin-top: 20px;", "Assembling the Pieces"),
      p(
        "From this exercise, it seems like the best model for district-level costs ",
        "involves treating supplies and teachers as fully variable and schools in ",
        "discrete increments. This seems like the right balance between complexity and ",
        "accuracy. So what's the final model?"
      ),

      p(
        "Because middle and high schools are added at a different cadence than ",
        "Elementary schools, it makes sense to keep them separate rather than modeling ",
        "adding generic schools. Using the \"district students to fill one school\" from ",
        "our analysis above, we can calculate the discrete number of schools at any given ",
        "enrollment. Our final model is thus as follows:"
      ),

      p(
        style = "margin-top: 16px; font-size: 15px;",
        "TC = $",
        format(school_cost, big.mark = ","),
        " ",
        HTML("&times;"),
        " [ceiling(Students / ",
        format(round(model_fit_elem_threshold), big.mark = ","),
        ") + ceiling(Students / ",
        format(round(model_fit_mid_threshold), big.mark = ","),
        ") + ceiling(Students / ",
        format(round(model_fit_high_threshold), big.mark = ","),
        ")] + ($",
        format(supply_rate, big.mark = ","),
        " + $",
        format(round(model_fit_blended_teacher_rate), big.mark = ","),
        ") ",
        HTML("&times;"),
        " Students"
      ),

      tags$ul(
        tags$li(
          "$",
          format(school_cost, big.mark = ","),
          " -- the fixed cost of a single ",
          "school building (Elementary, Middle, or High)."
        ),
        tags$li(
          "ceiling(Students / ",
          format(round(model_fit_elem_threshold), big.mark = ","),
          ") -- the number of Elementary schools needed, where ",
          format(round(model_fit_elem_threshold), big.mark = ","),
          " is the district-wide enrollment needed to fill one Elementary school ",
          "(from the table above)."
        ),
        tags$li(
          "ceiling(Students / ",
          format(round(model_fit_mid_threshold), big.mark = ","),
          ") -- the number of Middle schools needed, where ",
          format(round(model_fit_mid_threshold), big.mark = ","),
          " is the district-wide enrollment needed to fill one Middle school (from ",
          "the table above)."
        ),
        tags$li(
          "ceiling(Students / ",
          format(round(model_fit_high_threshold), big.mark = ","),
          ") -- the number of High schools needed, where ",
          format(round(model_fit_high_threshold), big.mark = ","),
          " is the district-wide enrollment needed to fill one High school (from the ",
          "table above)."
        ),
        tags$li(
          "$",
          format(supply_rate, big.mark = ","),
          " -- School supplies per student, ",
          "fully Variable."
        ),
        tags$li(
          "$",
          format(round(model_fit_blended_teacher_rate), big.mark = ","),
          " -- Teacher salaries per student, fully Variable: the blended rate ",
          "calculated in the \"How about teachers?\" section above, using each ",
          "band's actual average students per teacher rather than the standard ",
          "25 students/section."
        )
      ),

      hr(),
      h4(style = "margin-top: 20px;", "Model vs. Reality"),
      p(
        "Let's see how this model matches the district's actual cost curve. The plot ",
        "compares the model to the actual cost curve, and below that is a distribution ",
        "of errors at all points on the curve from 1-20,000 students."
      ),
      plotOutput("modelFitFinalPlot", height = "500px"),

      plotOutput("modelFitErrorDensity", height = "320px"),
      uiOutput("modelFitErrorSummary"),

      hr(),
      h5("Reflection Question"),
      p(
        "This model does pretty good, but for any given point on the cost curve, the ",
        "modeled cost is typically lower than the true cost (mean and median error is ",
        "negative). This pattern holds across different random seeds. Why do you think ",
        "this model consistently underestimates actual cost?"
      ),
      textAreaInput(
        "model_fit_error_q1_answer",
        label = NULL,
        placeholder = "Type your answer here...",
        rows = 4,
        width = "100%"
      ),

      wellPanel(
        numericInput(
          "rand_seed_model_fit",
          "Random Seed",
          value = 1,
          min = 1,
          step = 1
        ),
        helpText(
          "Change the Random Seed to view the implications of students arriving in ",
          "a different order. This only affects the plot above -- not the ",
          "histograms earlier on this tab."
        ),
        actionButton("generate_model_fit_final", "Refresh", width = "100%"),
        hr(),
        h5("Plot view"),
        sliderInput(
          "model_fit_final_view_range",
          "Enrollment range shown on graph (students)",
          min = 0,
          max = district_mc_max_n,
          value = c(0, 10000),
          step = 100
        ),
        helpText(
          "Widen this out (up to the full 0-20,000 range) to see more of the ",
          "district's cost curve at once."
        )
      )
    )
  ),

  tabPanel(
    "8. Takeaways",
    fluidPage(
      h4("Takeaways"),

      # Placeholder for an embedded video -- swap the contents of this div
      # for an iframe (e.g. a YouTube/Vimeo embed) when the video is ready.
      div(
        style = paste0(
          "width:100%; max-width:800px; aspect-ratio:16/9; background:#e9ecef; ",
          "border:2px dashed #adb5bd; border-radius:6px; display:flex; ",
          "align-items:center; justify-content:center; margin-bottom:20px;"
        ),
        p(
          style = "color:#6c757d; font-size:16px; margin:0;",
          "[Video placeholder]"
        )
      ),

      tags$ul(
        tags$li(
          "True cost curves are hard to work with. They may have odd shapes and ",
          "depending on the operating situation, may be unknowable even with a lot of ",
          "complicated modeling."
        ),
        tags$li(
          "Simplifying things to a linear model of costs with some being fixed and ",
          "some linearly increasing with volume can make the problem tractable, and in ",
          "some cases, produce more reliable estimates than more complicated models."
        ),
        tags$li(
          "The choice of what's variable and what's fixed may differ depending on the ",
          "type of change you're looking at. When looking at large changes, modeling the ",
          "precision of lots of discrete jumps is probably not worth it if the jumps are ",
          "relatively small."
        ),
        tags$li(
          "Fixed costs can be thought of as discrete increases in capacity. For a ",
          "certain amount of \"additional fixed costs,\" you are able to increase ",
          "production (in this case educate students) up to a certain amount. We can ",
          "think of these costs as not changing with volume within a certain range, but ",
          "moving outside that \"relevant range\" invalidates the assumption that costs ",
          "don't change with volume."
        ),
        tags$li(
          "Having a deep, intuitive understanding of how costs behave in your setting ",
          "is tremendously helpful for building a reasonable cost model."
        )
      )
    )
  )
)

# ---- Server -------------------------------------------------------------------
server <- function(input, output, session) {
  ##############################################################################
  # "7. Assessing Model Fit" tab: a standalone 1x4 (growth scenario) row of
  # histograms of the Monte Carlo actual Building expense increases
  # (model_fit_building_hist_data / model_fit_building_pred_lines,
  # precomputed once at load time above) against the variable-cost model's
  # single predicted Building expense increase for each growth scenario,
  # shown right where the "1,000 arrival patterns" narrative introduces it.
  ##############################################################################

  output$modelFitBuildingHistograms <- renderPlot({
    ggplot(model_fit_building_hist_data, aes(x = increase)) +
      geom_histogram(
        bins = 30,
        fill = palette_cb[["ink"]],
        color = palette_cb[["ink"]],
        alpha = 0.6,
        linewidth = 0.3
      ) +
      geom_vline(
        data = model_fit_building_pred_lines,
        aes(xintercept = predicted),
        color = "#D7263D",
        linewidth = 1,
        linetype = "dashed"
      ) +
      facet_wrap(~scenario, scales = "free_x", ncol = 4) +
      scale_x_continuous(labels = comma, expand = expansion(mult = 0.12)) +
      scale_y_continuous(
        limits = c(0, 1000),
        expand = expansion(mult = c(0, 0.04))
      ) +
      labs(
        title = "Actual Additional Building Expense Across 1,000 Random Draws (Seeds 3-1002) vs. Modeled Prediction",
        subtitle = "Dashed red line = the variable-cost model's predicted increase in building expense",
        x = "Additional Building Expense ($)",
        y = "Count"
      ) +
      theme_minimal(base_size = 13) +
      theme(
        axis.text.x = element_text(angle = 30, hjust = 1),
        plot.margin = margin(t = 8, r = 16, b = 8, l = 8)
      )
  })

  # Click-to-explain callout for the standalone Building-expense 1x4: each
  # panel is one growth scenario (facet_wrap(~ scenario) with a single
  # facet variable), so Shiny's click event reports which one was clicked
  # via panelvar1 -- same technique used for the highlighted ovals on the
  # Elementary/High School/District tabs, just without oval hit-testing
  # since here the whole panel is clickable.
  output$modelFitBuildingCallout <- renderUI({
    click <- input$modelFitBuildingClick
    panel <- click$panelvar1
    if (is.null(panel)) {
      return(NULL)
    }

    msg <- switch(
      panel,
      "+100 students" = paste0(
        "In none of the simulations did we need to add another school. As a result, ",
        "building expense always overestimates our cost increase by $",
        format(round(model_fit_blended_building_rate * 100), big.mark = ","),
        " (the blended rate times 100 students)."
      ),
      "+1,000 students" = paste0(
        "In all of the simulations, we needed to add a single elementary school. Again, ",
        "treating building expense as variable considerably overestimates the additional ",
        "costs we face from the increased enrollment."
      ),
      "+3,000 students" = paste0(
        "At this level of additions, we see some divergence in our simulations based on ",
        "arrival patterns. In almost all scenarios, we needed to open 5 schools. However, ",
        "for a handful of scenarios, we needed to open 6. Treating building expense as ",
        "fully variable is roughly equivalent to opening approximately 5.1 schools. We ",
        "can't open 0.1 of a school, but this number at least balances, to some extent, ",
        "the idea that sometimes we'll have to open 5 and sometimes we'll have to open 6. ",
        "Depending on how these numbers are going to be used, it may be useful to have the ",
        "expense reflect this remote possibility or it may be better to estimate 5 schools, ",
        "given that's the overwhelmingly likely scenario."
      ),
      "+6,000 students" = paste0(
        "When we increase enrollment by 6,000 students, in 1/8 of the simulations we ",
        "added 10 schools. In 7/8 of the simulations, we added 11. Using a variable cost ",
        "splits the difference almost proportionally."
      ),
      NULL
    )
    if (is.null(msg)) {
      return(NULL)
    }

    div(
      class = "situation-card",
      style = "font-size: 13px; line-height: 1.5;",
      tags$strong(sub("students$", "Students", panel)),
      " ",
      msg
    )
  })

  ##############################################################################
  # "7. Assessing Model Fit" tab: a second 1x4 (growth scenario) row of
  # histograms of the Monte Carlo actual Teacher expense increases
  # (model_fit_teacher_hist_data / model_fit_teacher_pred_lines,
  # precomputed once at load time above) against the variable-cost model's
  # single predicted Teacher expense increase for each growth scenario.
  # Filled gold (palette_cb[["highlow"]]), matching "Teacher salaries" on
  # the other tabs.
  ##############################################################################

  output$modelFitHistograms <- renderPlot({
    ggplot(model_fit_teacher_hist_data, aes(x = increase)) +
      geom_histogram(
        bins = 30,
        fill = palette_cb[["highlow"]],
        color = palette_cb[["ink"]],
        alpha = 0.6,
        linewidth = 0.3
      ) +
      geom_vline(
        data = model_fit_teacher_pred_lines,
        aes(xintercept = predicted),
        color = "#D7263D",
        linewidth = 1,
        linetype = "dashed"
      ) +
      facet_wrap(~scenario, scales = "free", ncol = 4) +
      scale_x_continuous(labels = comma, expand = expansion(mult = 0.12)) +
      scale_y_continuous(expand = expansion(mult = c(0, 0.12))) +
      labs(
        title = "Actual Additional Teacher Expense Across 1,000 Random Draws (Seeds 3-1002) vs. Modeled Prediction",
        subtitle = "Dashed red line = the variable-cost model's predicted increase in teacher expense",
        x = "Additional Teacher Expense ($)",
        y = "Count"
      ) +
      theme_minimal(base_size = 13) +
      theme(
        axis.text.x = element_text(angle = 30, hjust = 1),
        plot.margin = margin(t = 8, r = 16, b = 8, l = 8)
      )
  })

  # Click-to-explain callout for the Teacher-expense 1x4 -- same technique
  # as the Building-expense callout above (facet_wrap(~ scenario) reports
  # which panel was clicked via panelvar1).
  output$modelFitTeacherCallout <- renderUI({
    click <- input$modelFitTeacherClick
    panel <- click$panelvar1
    if (is.null(panel)) {
      return(NULL)
    }

    msg <- switch(
      panel,
      "+100 students" = paste0(
        "When adding 100 students, we rarely need to add teachers (<5% of the time). ",
        "However, treating teachers as fully variable results in an expected cost ",
        "increase of $",
        format(
          round(model_fit_teacher_predicted["+100 students"]),
          big.mark = ","
        ),
        " (~",
        round(model_fit_teacher_predicted["+100 students"] / teacher_cost, 1),
        " teachers) calculated using the blended rate."
      ),
      "+1,000 students" = paste0(
        "At an enrollment increase of 1,000 students, we see considerable divergence in ",
        "the number of teachers added. While the variable cost estimation is somewhat to ",
        "the high end of the possible cost increases, it is well within the realm of ",
        "possibilities."
      ),
      "+3,000 students" = "We see similar patterns as with +1,000 students.",
      "+6,000 students" = "The variable cost estimate is entirely reasonable.",
      NULL
    )
    if (is.null(msg)) {
      return(NULL)
    }

    div(
      class = "situation-card",
      style = "font-size: 13px; line-height: 1.5;",
      tags$strong(sub("students$", "Students", panel)),
      " ",
      msg
    )
  })

  ##############################################################################
  # "7. Assessing Model Fit" tab: the final discrete-step model ("Assembling
  # the Pieces" above) plotted against the district's TRUE total cost curve
  # for whichever seed is currently selected via the Random Seed control at
  # the bottom of this tab. Driven by its own trigger/seed reactiveVal pair
  # (same pattern as districtMCTrigger/districtMCSeedValue on tab 6) so it's
  # completely independent of the 1x4 histograms above -- those are
  # precomputed once at load time over a fixed bank of seeds, and this
  # Random Seed control does not touch them.
  ##############################################################################

  modelFitFinalTrigger <- reactiveVal(0)
  modelFitFinalSeedValue <- reactiveVal(1)

  observeEvent(input$generate_model_fit_final, {
    modelFitFinalSeedValue(input$rand_seed_model_fit)
    modelFitFinalTrigger(modelFitFinalTrigger() + 1)
  })

  modelFitFinalSim <- eventReactive(
    modelFitFinalTrigger(),
    {
      seed <- modelFitFinalSeedValue()
      max_n <- district_mc_max_n

      set.seed(seed)
      draws <- sample(grade_levels, max_n, replace = TRUE)

      ind <- sapply(grade_levels, function(g) as.integer(draws == g))
      cum_counts <- apply(ind, 2, cumsum)
      colnames(cum_counts) <- grade_levels

      elem_pos_vec <- rowSums(cum_counts[, elem_grades, drop = FALSE])
      mid_pos_vec <- rowSums(cum_counts[, middle_grades, drop = FALSE])
      high_pos_vec <- rowSums(cum_counts[, high_grades, drop = FALSE])

      elem_trace <- simulate_multi_elem(draws[draws %in% elem_grades])
      mid_trace <- simulate_multi_secondary(
        draws[draws %in% middle_grades],
        middle_grades,
        middle_classrooms_per_school
      )
      high_trace <- simulate_multi_secondary(
        draws[draws %in% high_grades],
        high_grades,
        high_classrooms_per_school
      )

      total_schools_vec <- band_lookup(elem_trace, elem_pos_vec, "schools") +
        band_lookup(mid_trace, mid_pos_vec, "schools") +
        band_lookup(high_trace, high_pos_vec, "schools")
      total_teachers_vec <- band_lookup(elem_trace, elem_pos_vec, "teachers") +
        band_lookup(mid_trace, mid_pos_vec, "teachers") +
        band_lookup(high_trace, high_pos_vec, "teachers")

      students <- seq_len(max_n)
      true_cost <- total_schools_vec *
        school_cost +
        total_teachers_vec * teacher_cost +
        students * supply_rate

      # The "Assembling the Pieces" model: discrete school buildings per band
      # (ceiling of enrollment over each band's fill threshold), plus fully
      # Variable teacher (blended calculated rate, not the standard $80,000/25)
      # and supply costs.
      modeled_cost <- school_cost *
        (ceiling(students / model_fit_elem_threshold) +
          ceiling(students / model_fit_mid_threshold) +
          ceiling(students / model_fit_high_threshold)) +
        (supply_rate + model_fit_blended_teacher_rate) * students

      data.table(
        students = students,
        true_cost = true_cost,
        modeled_cost = modeled_cost
      )
    },
    ignoreNULL = FALSE,
    ignoreInit = FALSE
  )

  output$modelFitFinalPlot <- renderPlot({
    sim <- modelFitFinalSim()

    view_range <- input$model_fit_final_view_range
    validate(need(
      !is.null(view_range) &&
        length(view_range) == 2 &&
        view_range[2] > view_range[1],
      "Widen the plot view range slider -- the minimum can't equal the maximum."
    ))
    view_lo <- max(0, view_range[1])
    view_hi <- min(nrow(sim), view_range[2])

    plot_data <- rbindlist(list(
      data.table(
        students = sim$students,
        cost = sim$true_cost,
        series = "True cost"
      ),
      data.table(
        students = sim$students,
        cost = sim$modeled_cost,
        series = "Final model"
      )
    ))
    plot_data[,
      series := factor(series, levels = c("True cost", "Final model"))
    ]

    visible_idx <- which(sim$students >= view_lo & sim$students <= view_hi)
    y_max_visible <- max(
      sim$true_cost[visible_idx],
      sim$modeled_cost[visible_idx]
    )

    ggplot(
      plot_data,
      aes(x = students, y = cost, color = series, linetype = series)
    ) +
      geom_line(linewidth = 0.8) +
      scale_color_manual(
        name = NULL,
        values = c("True cost" = palette_cb[["ink"]], "Final model" = "#D7263D")
      ) +
      scale_linetype_manual(
        name = NULL,
        values = c("True cost" = "solid", "Final model" = "dashed")
      ) +
      coord_cartesian(
        xlim = c(view_lo, view_hi),
        ylim = c(0, y_max_visible * 1.12)
      ) +
      scale_x_continuous(labels = comma) +
      scale_y_continuous(labels = comma) +
      labs(
        title = paste0(
          "Final Model vs. True District Cost, ",
          format(view_lo, big.mark = ","),
          "-",
          format(view_hi, big.mark = ","),
          " Students (Seed ",
          modelFitFinalSeedValue(),
          ")"
        ),
        x = "Students",
        y = "Total Cost ($)"
      ) +
      theme_minimal(base_size = 13) +
      theme(legend.position = "bottom")
  })

  # Kernel density of the model's error (Final model - True cost) at every
  # single enrollment level from 1 to district_mc_max_n (20,000 data
  # points), for whichever seed is currently selected. Reuses
  # modelFitFinalSim() -- the same simulation that drives the plot above --
  # so this always reflects the exact same draw, over its full range
  # (independent of the "Plot view" zoom slider, which only affects the
  # plot above).
  output$modelFitErrorDensity <- renderPlot({
    sim <- modelFitFinalSim()
    error_data <- data.table(error = sim$modeled_cost - sim$true_cost)

    ggplot(error_data, aes(x = error)) +
      geom_density(
        fill = "grey70",
        color = "grey30",
        alpha = 0.6,
        linewidth = 0.7
      ) +
      geom_vline(
        xintercept = 0,
        color = "grey20",
        linewidth = 1,
        linetype = "solid"
      ) +
      scale_x_continuous(labels = comma) +
      labs(
        title = paste0(
          "Distribution of Model Error, 1-",
          format(nrow(sim), big.mark = ","),
          " Students (Seed ",
          modelFitFinalSeedValue(),
          ")"
        ),
        subtitle = "Error = Final model cost - True cost (solid line = zero error)",
        x = "Error ($)",
        y = "Density"
      ) +
      theme_minimal(base_size = 13)
  })

  output$modelFitErrorSummary <- renderUI({
    sim <- modelFitFinalSim()
    error <- sim$modeled_cost - sim$true_cost

    p(
      style = "margin-top: 4px; margin-bottom: 16px;",
      strong("Mean error: "),
      paste0("$", format(round(mean(error)), big.mark = ",")),
      HTML("&nbsp;&nbsp;|&nbsp;&nbsp;"),
      strong("Median error: "),
      paste0("$", format(round(median(error)), big.mark = ",")),
      HTML("&nbsp;&nbsp;|&nbsp;&nbsp;"),
      strong("Std. dev.: "),
      paste0("$", format(round(sd(error)), big.mark = ","))
    )
  })

  ##############################################################################
  # Shared "current student body" parameters (used by the Elementary and
  # High School tabs)
  ##############################################################################

  # Shared "current student body" parameters. The Elementary and High
  # School tabs' Generate buttons both write into this one reactiveValues
  # object, and their random-seed fields are kept in sync with it.
  body_params <- reactiveValues(n = 5000, seed = 1)

  # The Elementary/High School tabs don't expose a student-count field at
  # all -- they always generate this many students in the background, which
  # is comfortably enough for both schools to run out of classroom capacity
  # well before this pool is exhausted, whatever the current seed's mix.
  elem_high_default_n <- 25000

  observeEvent(input$generate_body_elem, {
    body_params$n <- elem_high_default_n
    body_params$seed <- input$rand_seed_elem
  })
  observeEvent(input$generate_body_high, {
    body_params$n <- elem_high_default_n
    body_params$seed <- input$rand_seed_high
  })
  observeEvent(input$generate_body_high_mc, {
    body_params$n <- elem_high_default_n
    body_params$seed <- input$rand_seed_high_mc
  })

  # Puts every control on the "5. Modeling Choices: High School" tab back to
  # its original default, including the random seed, and re-triggers the
  # same body-generation the Refresh button would (so the plot/stats update
  # even if the seed was already 1 and wouldn't otherwise re-fire).
  observeEvent(input$mc_reset_defaults, {
    updateSliderInput(session, "mc_start", value = 725)
    updateSliderInput(session, "mc_delta", value = 50)
    updateNumericInput(session, "mc_school_cost", value = school_cost)
    updateNumericInput(session, "mc_supply_rate", value = supply_rate)
    updateNumericInput(session, "mc_teacher_cost", value = teacher_cost)
    updateNumericInput(session, "mc_teacher_capacity", value = teacher_capacity)
    updateRadioButtons(session, "mc_building_choice", selected = "Variable")
    updateRadioButtons(session, "mc_supplies_choice", selected = "Variable")
    updateRadioButtons(session, "mc_teacher_choice", selected = "Variable")
    updateNumericInput(session, "rand_seed_high_mc", value = 1)
    body_params$n <- elem_high_default_n
    body_params$seed <- 1
  })

  observeEvent(
    body_params$seed,
    {
      updateNumericInput(session, "rand_seed_elem", value = body_params$seed)
      updateNumericInput(session, "rand_seed_high", value = body_params$seed)
      updateNumericInput(session, "rand_seed_high_mc", value = body_params$seed)
    },
    ignoreInit = TRUE
  )

  # Keeps the "Change in enrollment" slider's own range in sync with the
  # starting enrollment, so the ending enrollment (start + delta) can never
  # be pushed below 0 or above the full enrollment the current high school
  # draw admits -- while still allowing decreases (negative delta) as well
  # as increases.
  observe({
    cap <- nrow(highSim()$trace)
    lo <- -input$mc_start
    hi <- max(lo, cap - input$mc_start)
    updateSliderInput(
      session,
      "mc_delta",
      min = lo,
      max = hi,
      value = min(max(input$mc_delta, lo), hi)
    )
  })

  # Shared district-wide random draw (ordered), rebuilt whenever body_params
  # changes. This is the single source of truth for the current student
  # body -- the Elementary and High School Cost Implications tabs both
  # read from it.
  studentDraws <- reactive({
    set.seed(body_params$seed)
    sample(grade_levels, body_params$n, replace = TRUE)
  })

  ##############################################################################
  # Elementary/High School Cost Implications tabs: fill one school from
  # empty, one student at a time, using the shared studentDraws() above.
  ##############################################################################

  elemSim <- reactive({
    simulate_elem_school(studentDraws()[studentDraws() %in% elem_grades])
  })

  # Geometry (in data coordinates) for the highlight ovals: one marking the
  # building-expense jump at student 1, plus three marking the "waves" of
  # teacher hiring -- wave 1 = every grade's 1st classroom, wave 2 = every
  # grade's 2nd, wave 3 = every grade's 3rd. Recomputed from the CURRENT
  # simulation, so the ovals track wherever those clusters actually land for
  # the active seed/draw. Each region also records which FACET PANEL it
  # belongs to, since building and teacher jumps now live in separate rows.
  elemWaveRegions <- reactive({
    result <- elemSim()
    sim <- result$trace
    ev <- result$events
    if (nrow(sim) == 0) {
      return(list())
    }

    teacher_cum <- sim$teachers * teacher_cost
    teacher_max <- max(teacher_cum)

    building_region <- list(
      key = "building",
      panel = "Building Expense",
      cx = 1,
      cy = school_cost / 2,
      rx = max(nrow(sim) * 0.03, 1.5),
      ry = school_cost / 2 * 1.15,
      label = elem_wave_text[["building"]]
    )

    # Supplies cost is a straight line (supply_rate per student), so the
    # oval just hugs a point partway along that ramp rather than a jump.
    supplies_max <- supply_rate * nrow(sim)
    sup_cx <- nrow(sim) * 0.6
    supplies_region <- list(
      key = "supplies",
      panel = "School Supplies",
      cx = sup_cx,
      cy = supply_rate * sup_cx,
      rx = max(nrow(sim) * 0.07, 3),
      ry = max(supplies_max * 0.09, 1),
      label = elem_wave_text[["supplies"]]
    )

    wave_regions <- if (nrow(ev) > 0) {
      Filter(
        Negate(is.null),
        lapply(1:3, function(w) {
          sub <- ev[wave == w]
          if (nrow(sub) == 0) {
            return(NULL)
          }
          xmin <- min(sub$students)
          xmax <- max(sub$students)
          pad_x <- max((xmax - xmin) * 0.15, 3)

          # Hug just the step-jump zone itself in the Teacher Salaries panel.
          y_before <- if (xmin > 1) teacher_cum[xmin - 1] else 0
          y_after <- teacher_cum[xmax]
          pad_y <- max((y_after - y_before) * 0.35, teacher_max * 0.02)

          list(
            key = as.character(w),
            panel = "Teacher Salaries",
            cx = (xmin + xmax) / 2,
            cy = (y_before + y_after) / 2,
            rx = (xmax - xmin) / 2 + pad_x,
            ry = (y_after - y_before) / 2 + pad_y,
            label = elem_wave_text[[as.character(w)]]
          )
        })
      )
    } else {
      list()
    }

    c(list(building_region, supplies_region), wave_regions)
  })

  # Elementary tick spacing is finer than the District tab's ($500,000 vs
  # $10,000,000), since one school's costs are naturally a much smaller
  # scale than the whole district's.
  elem_tick_step <- 5e5

  # Back to the same technique used on the District tab: ONE ggplot object,
  # faceted by row with scales = "free_y" AND space = "free_y". ggplot's
  # own layout engine then sizes each row's plotting area exactly
  # proportional to that row's own data range -- trying to reproduce that
  # by hand across four separate plot devices (the previous approach)
  # never quite matched, because it required guessing how many pixels of
  # "chrome" (title/axis/margins) ggplot would actually use. This also
  # restores reliable click handling: Shiny reports which facet row was
  # clicked via `panelvar1`, so hit-testing the ovals works the same way
  # it did when they were separate plots.
  output$elemCostPlot <- renderPlot({
    sim <- elemSim()$trace
    validate(need(
      nrow(sim) > 0,
      "No K-5 students in the current draw yet -- click Refresh."
    ))

    building_cum <- rep(school_cost, nrow(sim))
    supplies_cum <- sim$students * supply_rate
    teacher_cum <- sim$teachers * teacher_cost
    total_cum <- building_cum + supplies_cum + teacher_cum

    shared_breaks <- seq(
      0,
      ceiling(max(total_cum) / elem_tick_step) * elem_tick_step,
      by = elem_tick_step
    )

    long <- rbind(
      data.table(
        students = sim$students,
        ymin = 0,
        ymax = building_cum,
        component = "Building expense",
        panel = "Building Expense"
      ),
      data.table(
        students = sim$students,
        ymin = 0,
        ymax = supplies_cum,
        component = "School supplies",
        panel = "School Supplies"
      ),
      data.table(
        students = sim$students,
        ymin = 0,
        ymax = teacher_cum,
        component = "Teacher salaries",
        panel = "Teacher Salaries"
      ),
      data.table(
        students = sim$students,
        ymin = 0,
        ymax = building_cum,
        component = "Building expense",
        panel = "Total"
      ),
      data.table(
        students = sim$students,
        ymin = building_cum,
        ymax = building_cum + supplies_cum,
        component = "School supplies",
        panel = "Total"
      ),
      data.table(
        students = sim$students,
        ymin = building_cum + supplies_cum,
        ymax = total_cum,
        component = "Teacher salaries",
        panel = "Total"
      )
    )
    long[,
      component := factor(
        component,
        levels = c("Building expense", "School supplies", "Teacher salaries")
      )
    ]
    long[,
      panel := factor(
        panel,
        levels = c(
          "Building Expense",
          "School Supplies",
          "Teacher Salaries",
          "Total"
        )
      )
    ]

    # Highlight ovals, routed to their own facet row via each region's
    # `panel`. Whichever one matches the current click selection is drawn
    # in solid red with a thicker outline (fill stays white either way,
    # so it never blends into the navy/teal/gold ribbon underneath).
    regions <- elemWaveRegions()
    selected_key <- if (!is.null(elemSelected())) elemSelected()$key else NULL
    ellipse_layers <- NULL
    if (length(regions) > 0) {
      theta <- seq(0, 2 * pi, length.out = 100)
      ellipse_df <- rbindlist(lapply(regions, function(r) {
        data.table(
          x = r$cx + r$rx * cos(theta),
          y = r$cy + r$ry * sin(theta),
          region_id = r$key,
          panel = factor(r$panel, levels = levels(long$panel)),
          selected = identical(r$key, selected_key)
        )
      }))
      ellipse_layers <- list(
        geom_polygon(
          data = ellipse_df,
          aes(
            x = x,
            y = y,
            group = region_id,
            color = selected,
            linewidth = selected,
            linetype = selected
          ),
          inherit.aes = FALSE,
          fill = "white",
          alpha = 0.32
        ),
        scale_color_manual(
          values = c(`TRUE` = "#D7263D", `FALSE` = palette_cb[["ink"]]),
          guide = "none"
        ),
        scale_linewidth_manual(
          values = c(`TRUE` = 2.2, `FALSE` = 0.9),
          guide = "none"
        ),
        scale_linetype_manual(
          values = c(`TRUE` = "solid", `FALSE` = "dashed"),
          guide = "none"
        )
      )
    }

    ggplot(
      long,
      aes(x = students, ymin = ymin, ymax = ymax, fill = component)
    ) +
      geom_ribbon() +
      {
        if (!is.null(ellipse_layers)) ellipse_layers
      } +
      scale_fill_manual(
        values = c(
          "Building expense" = palette_cb[["ink"]],
          "School supplies" = palette_cb[["facility"]],
          "Teacher salaries" = palette_cb[["highlow"]]
        )
      ) +
      facet_grid(
        rows = vars(panel),
        scales = "free_y",
        space = "free_y",
        labeller = labeller(panel = label_wrap_gen(10))
      ) +
      scale_x_continuous(labels = comma) +
      scale_y_continuous(labels = comma, breaks = shared_breaks) +
      labs(
        title = "Cost Buildup for One Elementary School, One Student at a Time",
        x = "Students Admitted",
        y = "Cost ($)",
        fill = "Cost Component"
      ) +
      theme_minimal(base_size = 12) +
      theme(
        legend.position = "top",
        strip.text.y = element_text(face = "bold", angle = 0),
        panel.spacing = unit(1.4, "lines")
      )
  })

  # One selection for the whole composite plot -- since a click can only
  # land in one facet row at a time, there's no risk of two callouts
  # showing at once (unlike the earlier two-reactiveVal version).
  elemSelected <- reactiveVal(NULL)

  observeEvent(input$elemPlotClick, {
    click <- input$elemPlotClick
    clicked_panel <- click$panelvar1
    hit <- NULL
    if (!is.null(clicked_panel)) {
      for (r in Filter(
        function(r) r$panel == clicked_panel,
        elemWaveRegions()
      )) {
        in_oval <- ((click$x - r$cx) / r$rx)^2 + ((click$y - r$cy) / r$ry)^2 <=
          1
        if (isTRUE(in_oval)) {
          hit <- r
          break
        }
      }
    }
    elemSelected(hit)
  })

  observeEvent(elemSim(), {
    elemSelected(NULL)
  })

  # Right-hand column: one vertical block per facet row, in the same
  # order and with the same relative weights (each row's own peak dollar
  # value) that drive the plot's own space = "free_y" heights, so a
  # callout lands roughly opposite the row its oval belongs to. School
  # Supplies and Total never get callouts -- their blocks are just
  # spacers that hold their share of the height so the alignment isn't
  # thrown off. (This is a CSS approximation, not a pixel-exact
  # measurement of the rendered plot -- nudge the weights below if a
  # callout looks noticeably off from its oval.)
  output$elemNotesColumn <- renderUI({
    sim <- elemSim()$trace
    if (nrow(sim) == 0) {
      return(NULL)
    }

    building_cum <- rep(school_cost, nrow(sim))
    supplies_cum <- sim$students * supply_rate
    teacher_cum <- sim$teachers * teacher_cost
    total_cum <- building_cum + supplies_cum + teacher_cum

    w_building <- max(building_cum)
    w_supplies <- max(supplies_cum)
    w_teacher <- max(teacher_cum)
    w_total <- max(total_cum)

    sel <- elemSelected()
    note_block <- function(r) {
      if (is.null(r)) {
        return(NULL)
      }
      div(
        class = "situation-card",
        style = "font-size: 13px; line-height: 1.5;",
        HTML(r$label)
      )
    }
    building_note <- if (!is.null(sel) && sel$panel == "Building Expense") {
      note_block(sel)
    } else {
      NULL
    }
    supplies_note <- if (!is.null(sel) && sel$panel == "School Supplies") {
      note_block(sel)
    } else {
      NULL
    }
    teacher_note <- if (!is.null(sel) && sel$panel == "Teacher Salaries") {
      note_block(sel)
    } else {
      NULL
    }

    # The composite plot has a title + top legend sitting above its first
    # facet row, which this column otherwise has no equivalent of -- without
    # this spacer, every callout renders too high because nothing offsets
    # it by that shared header chrome. Within each row's own block, the
    # callout is centered vertically so it lines up with the oval near the
    # middle of that row instead of hugging the block's top edge.
    header_spacer_px <- 70

    div(
      style = "display: flex; flex-direction: column; height: 900px;",
      div(style = paste0("height: ", header_spacer_px, "px; flex: none;")),
      div(
        style = paste0(
          "flex: ",
          w_building,
          " 1 0; min-height: 110px; display: flex; align-items: center; padding: 4px;"
        ),
        building_note
      ),
      div(
        style = paste0(
          "flex: ",
          w_supplies,
          " 1 0; min-height: 110px; display: flex; align-items: center; padding: 4px;"
        ),
        supplies_note
      ),
      div(
        style = paste0(
          "flex: ",
          w_teacher,
          " 1 0; min-height: 110px; display: flex; align-items: center; padding: 4px;"
        ),
        teacher_note
      ),
      div(style = paste0("flex: ", w_total, " 1 0;"))
    )
  })

  output$elemCostSummary <- renderUI({
    result <- elemSim()
    sim <- result$trace
    n_admitted <- if (nrow(sim) > 0) max(sim$students) else 0
    final_cost <- if (nrow(sim) > 0) max(sim$total_cost) else 0
    final_teach <- if (nrow(sim) > 0) max(sim$teachers) else 0
    capped_grade <- result$capped_grade
    capped_label <- if (!is.na(capped_grade)) {
      if (capped_grade == "K") {
        "Kindergarten"
      } else {
        paste0("Grade ", capped_grade)
      }
    } else {
      NA_character_
    }

    HTML(paste0(
      "<div style='font-size:15px; line-height:1.7;'>",
      "<b>Students this school could actually admit:</b> ",
      format(n_admitted, big.mark = ","),
      if (!is.na(capped_grade)) {
        paste0(
          " (",
          capped_label,
          " filled its 3 classrooms before the school reached 450)"
        )
      } else {
        ""
      },
      "<br><b>Teachers needed:</b> ",
      final_teach,
      "<br>",
      "<b>Total cost for the elementary school at that enrollment:</b> $",
      format(round(final_cost), big.mark = ","),
      "</div>"
    ))
  })

  highSim <- reactive({
    simulate_high_school(studentDraws()[studentDraws() %in% high_grades])
  })

  # Geometry (in data coordinates) for the two highlight ovals on the
  # Teacher Salaries panel. simulate_high_school() doesn't track hiring
  # "events" the way simulate_elem_school() does, but every teacher jump
  # is already visible in sim$teachers as a step -- diff() picks those
  # jumps out directly from the trace.
  #   - "vertical" circles one jump itself, illustrating that teachers
  #     always arrive in a block of six (one per subject).
  #   - "horizontal" circles the flat run BEFORE a jump (the widest one,
  #     for a clear example), illustrating that a step's width isn't
  #     fixed -- it depends on the arrival order of students.
  highWaveRegions <- reactive({
    result <- highSim()
    sim <- result$trace
    if (nrow(sim) == 0) {
      return(list())
    }

    teacher_cum <- sim$teachers * teacher_cost
    teacher_max <- max(teacher_cum)

    jump_at <- which(diff(c(0L, sim$teachers)) > 0)
    if (length(jump_at) == 0) {
      return(list())
    }

    gaps <- diff(c(0L, jump_at)) # width (# students) of the flat run immediately before each jump

    vert_idx <- max(1, ceiling(length(jump_at) / 2))
    vert_pick <- jump_at[vert_idx]

    # The very first jump always happens right at student 1 (even one
    # student is enough to need each subject's first teacher), so it has
    # no real flat run before it -- skip any candidate like that, and
    # skip whichever jump was already picked for the vertical oval, so
    # the two ovals land in visibly different places.
    horiz_order <- order(gaps, decreasing = TRUE)
    horiz_idx <- NA_integer_
    for (idx in horiz_order) {
      if (idx != vert_idx && jump_at[idx] > 1) {
        horiz_idx <- idx
        break
      }
    }
    if (is.na(horiz_idx)) {
      horiz_idx <- horiz_order[1]
    }
    horiz_pick <- jump_at[horiz_idx]
    horiz_gap <- gaps[horiz_idx]

    y_before <- if (vert_pick > 1) teacher_cum[vert_pick - 1] else 0
    y_after <- teacher_cum[vert_pick]
    pad_y <- max((y_after - y_before) * 0.35, teacher_max * 0.02)
    vertical_region <- list(
      key = "vertical",
      panel = "Teacher Salaries",
      cx = vert_pick,
      cy = (y_before + y_after) / 2,
      rx = max(nrow(sim) * 0.012, 1.2),
      ry = (y_after - y_before) / 2 + pad_y,
      label = high_wave_text[["vertical"]]
    )

    xmax <- max(horiz_pick - 1, 1)
    xmin <- max(horiz_pick - horiz_gap, 1)
    if (xmax < xmin) {
      xmax <- xmin
    }
    flat_y <- teacher_cum[xmax]
    pad_x <- max((xmax - xmin) * 0.08, 1.5)
    horizontal_region <- list(
      key = "horizontal",
      panel = "Teacher Salaries",
      cx = (xmin + xmax) / 2,
      cy = flat_y,
      rx = (xmax - xmin) / 2 + pad_x,
      ry = max(teacher_max * 0.025, 1),
      label = high_wave_text[["horizontal"]]
    )

    list(vertical_region, horizontal_region)
  })

  # Same composite-facet technique as Elementary and District: ONE ggplot
  # object, faceted by row with scales = "free_y" AND space = "free_y",
  # so panel heights stay exactly proportional to each row's own dollar
  # range, and Shiny's facet-aware click handling (panelvar1) keeps the
  # ovals clickable.
  output$highCostPlot <- renderPlot({
    sim <- highSim()$trace
    validate(need(
      nrow(sim) > 0,
      "No 9-12 students in the current draw yet -- click Refresh."
    ))

    building_cum <- rep(school_cost, nrow(sim))
    supplies_cum <- sim$students * supply_rate
    teacher_cum <- sim$teachers * teacher_cost
    total_cum <- building_cum + supplies_cum + teacher_cum

    tick_step <- 5e5
    shared_breaks <- seq(
      0,
      ceiling(max(total_cum) / tick_step) * tick_step,
      by = tick_step
    )

    long <- rbind(
      data.table(
        students = sim$students,
        ymin = 0,
        ymax = building_cum,
        component = "Building expense",
        panel = "Building Expense"
      ),
      data.table(
        students = sim$students,
        ymin = 0,
        ymax = supplies_cum,
        component = "School supplies",
        panel = "School Supplies"
      ),
      data.table(
        students = sim$students,
        ymin = 0,
        ymax = teacher_cum,
        component = "Teacher salaries",
        panel = "Teacher Salaries"
      ),
      data.table(
        students = sim$students,
        ymin = 0,
        ymax = building_cum,
        component = "Building expense",
        panel = "Total"
      ),
      data.table(
        students = sim$students,
        ymin = building_cum,
        ymax = building_cum + supplies_cum,
        component = "School supplies",
        panel = "Total"
      ),
      data.table(
        students = sim$students,
        ymin = building_cum + supplies_cum,
        ymax = total_cum,
        component = "Teacher salaries",
        panel = "Total"
      )
    )
    long[,
      component := factor(
        component,
        levels = c("Building expense", "School supplies", "Teacher salaries")
      )
    ]
    long[,
      panel := factor(
        panel,
        levels = c(
          "Building Expense",
          "School Supplies",
          "Teacher Salaries",
          "Total"
        )
      )
    ]

    regions <- highWaveRegions()
    selected_key <- if (!is.null(highSelected())) highSelected()$key else NULL
    ellipse_layers <- NULL
    if (length(regions) > 0) {
      theta <- seq(0, 2 * pi, length.out = 100)
      ellipse_df <- rbindlist(lapply(regions, function(r) {
        data.table(
          x = r$cx + r$rx * cos(theta),
          y = r$cy + r$ry * sin(theta),
          region_id = r$key,
          panel = factor(r$panel, levels = levels(long$panel)),
          selected = identical(r$key, selected_key)
        )
      }))
      ellipse_layers <- list(
        geom_polygon(
          data = ellipse_df,
          aes(
            x = x,
            y = y,
            group = region_id,
            color = selected,
            linewidth = selected,
            linetype = selected
          ),
          inherit.aes = FALSE,
          fill = "white",
          alpha = 0.32
        ),
        scale_color_manual(
          values = c(`TRUE` = "#D7263D", `FALSE` = palette_cb[["ink"]]),
          guide = "none"
        ),
        scale_linewidth_manual(
          values = c(`TRUE` = 2.2, `FALSE` = 0.9),
          guide = "none"
        ),
        scale_linetype_manual(
          values = c(`TRUE` = "solid", `FALSE` = "dashed"),
          guide = "none"
        )
      )
    }

    ggplot(
      long,
      aes(x = students, ymin = ymin, ymax = ymax, fill = component)
    ) +
      geom_ribbon() +
      {
        if (!is.null(ellipse_layers)) ellipse_layers
      } +
      scale_fill_manual(
        values = c(
          "Building expense" = palette_cb[["ink"]],
          "School supplies" = palette_cb[["facility"]],
          "Teacher salaries" = palette_cb[["highlow"]]
        )
      ) +
      facet_grid(
        rows = vars(panel),
        scales = "free_y",
        space = "free_y",
        labeller = labeller(panel = label_wrap_gen(10))
      ) +
      scale_x_continuous(labels = comma) +
      scale_y_continuous(labels = comma, breaks = shared_breaks) +
      labs(
        title = "Cost Buildup for One High School, One Student at a Time",
        x = "Students Admitted",
        y = "Cost ($)",
        fill = "Cost Component"
      ) +
      theme_minimal(base_size = 12) +
      theme(
        legend.position = "top",
        strip.text.y = element_text(face = "bold", angle = 0),
        panel.spacing = unit(1.4, "lines")
      )
  })

  highSelected <- reactiveVal(NULL)

  observeEvent(input$highPlotClick, {
    click <- input$highPlotClick
    clicked_panel <- click$panelvar1
    hit <- NULL
    if (!is.null(clicked_panel)) {
      for (r in Filter(
        function(r) r$panel == clicked_panel,
        highWaveRegions()
      )) {
        in_oval <- ((click$x - r$cx) / r$rx)^2 + ((click$y - r$cy) / r$ry)^2 <=
          1
        if (isTRUE(in_oval)) {
          hit <- r
          break
        }
      }
    }
    highSelected(hit)
  })

  observeEvent(highSim(), {
    highSelected(NULL)
  })

  # Right-hand column, same layout technique as Elementary: one block per
  # facet row, weighted by that row's own peak dollar value so it lines
  # up roughly with the corresponding row in the plot. Both ovals live in
  # the Teacher Salaries row, so only that block ever shows a callout.
  output$highNotesColumn <- renderUI({
    sim <- highSim()$trace
    if (nrow(sim) == 0) {
      return(NULL)
    }

    building_cum <- rep(school_cost, nrow(sim))
    supplies_cum <- sim$students * supply_rate
    teacher_cum <- sim$teachers * teacher_cost
    total_cum <- building_cum + supplies_cum + teacher_cum

    w_building <- max(building_cum)
    w_supplies <- max(supplies_cum)
    w_teacher <- max(teacher_cum)
    w_total <- max(total_cum)

    sel <- highSelected()
    teacher_note <- if (!is.null(sel) && sel$panel == "Teacher Salaries") {
      div(
        class = "situation-card",
        style = "font-size: 13px; line-height: 1.5;",
        HTML(sel$label)
      )
    } else {
      NULL
    }

    header_spacer_px <- 70

    div(
      style = "display: flex; flex-direction: column; height: 900px;",
      div(style = paste0("height: ", header_spacer_px, "px; flex: none;")),
      div(style = paste0("flex: ", w_building, " 1 0;")),
      div(style = paste0("flex: ", w_supplies, " 1 0;")),
      div(
        style = paste0(
          "flex: ",
          w_teacher,
          " 1 0; min-height: 110px; display: flex; align-items: center; padding: 4px;"
        ),
        teacher_note
      ),
      div(style = paste0("flex: ", w_total, " 1 0;"))
    )
  })

  output$highCostSummary <- renderUI({
    result <- highSim()
    sim <- result$trace
    n_admitted <- if (nrow(sim) > 0) max(sim$students) else 0
    final_cost <- if (nrow(sim) > 0) max(sim$total_cost) else 0
    final_teach <- if (nrow(sim) > 0) max(sim$teachers) else 0
    capped_label <- if (!is.na(result$capped_grade)) {
      paste0("Grade ", result$capped_grade)
    } else {
      NA_character_
    }

    HTML(paste0(
      "<div style='font-size:15px; line-height:1.7;'>",
      "<b>Students this school could actually admit:</b> ",
      format(n_admitted, big.mark = ","),
      if (result$capped) {
        paste0(
          " (",
          capped_label,
          " classrooms are completely full and there are no empty classrooms to add ",
          "additional classes. This is shy of the 1,200-student theoretical maximum.)"
        )
      } else {
        " (not enough 9-12 students in the current draw to fill this school)"
      },
      "<br><b>Teachers needed:</b> ",
      final_teach,
      "<br>",
      "<b>Total cost for the high school at that enrollment:</b> $",
      format(round(final_cost), big.mark = ","),
      "</div>"
    ))
  })

  ##############################################################################
  # Modeling Choices tab server logic: fits a straight-line (fixed + rate x
  # students) model to the high school's REAL simulated cost curve (the same
  # highSim() used by the "3. High School" tab), anchored at a chosen
  # starting enrollment, and compares it against the true cost at
  # start + delta. "Fixed" components hold their $ value at the starting
  # enrollment constant across the whole window; "Variable" components use
  # a $/student rate -- supply_rate for Supplies, teacher_cost/teacher_
  # capacity for Teachers (this matches the true model's average teacher
  # cost per student, since teachers arrive in blocks of 6 covering 6
  # sections x 25 students = 150 student-subject-slots, i.e. 25 real
  # students per teacher), and school_cost/high_capacity_per_school for
  # Building (school_cost spread evenly across the school's 1,200-student
  # theoretical capacity).
  ##############################################################################

  output$modelChoicePlot <- renderPlot({
    sim <- highSim()$trace
    start <- input$mc_start
    delta <- input$mc_delta
    end <- start + delta

    validate(need(
      nrow(sim) >= end,
      paste0(
        "The current high school draw only admits ",
        nrow(sim),
        " students -- lower the starting enrollment or change in ",
        "enrollment, or generate a new draw on the \"3. High School\" tab."
      )
    ))

    mc_school_cost <- input$mc_school_cost
    mc_supply_rate <- input$mc_supply_rate
    mc_teacher_cost <- input$mc_teacher_cost
    mc_teacher_capacity <- input$mc_teacher_capacity
    validate(need(
      !is.na(mc_school_cost) &&
        !is.na(mc_supply_rate) &&
        !is.na(mc_teacher_cost) &&
        !is.na(mc_teacher_capacity) &&
        mc_school_cost >= 0 &&
        mc_supply_rate >= 0 &&
        mc_teacher_cost >= 0 &&
        mc_teacher_capacity >= 1,
      "Cost assumptions must be non-negative numbers, and capacity must be at least 1."
    ))

    # The building's total student capacity is built up from the same
    # per-teacher section capacity the user can now edit -- a teacher covers
    # `teacher_classes_per_day` sections, and the school has room for
    # `high_classrooms_per_school / length(subjects)` teachers per subject.
    mc_teacher_student_capacity <- mc_teacher_capacity * teacher_classes_per_day
    mc_high_capacity_per_school <- floor(
      high_classrooms_per_school / length(subjects)
    ) *
      mc_teacher_student_capacity

    building_cum <- rep(mc_school_cost, nrow(sim))
    supplies_cum <- sim$students * mc_supply_rate
    teacher_cum <- sim$teachers * mc_teacher_cost
    total_cum <- building_cum + supplies_cum + teacher_cum

    building_at_start <- idx_or_zero(building_cum, start)
    teacher_at_start <- idx_or_zero(teacher_cum, start)
    true_start <- idx_or_zero(total_cum, start)
    true_end <- idx_or_zero(total_cum, end)

    fixed_part <- 0
    var_rate <- 0
    if (input$mc_supplies_choice == "Variable") {
      var_rate <- var_rate + mc_supply_rate
    } else {
      fixed_part <- fixed_part + mc_supply_rate * start
    }
    if (input$mc_teacher_choice == "Variable") {
      var_rate <- var_rate + mc_teacher_cost / mc_teacher_capacity
    } else {
      fixed_part <- fixed_part + teacher_at_start
    }
    if (input$mc_building_choice == "Variable") {
      var_rate <- var_rate + mc_school_cost / mc_high_capacity_per_school
    } else {
      fixed_part <- fixed_part + building_at_start
    }

    model_end <- fixed_part + var_rate * end
    model_start <- fixed_part + var_rate * start

    # Show the FULL enrollment range the school actually admits (not just a
    # narrow window around start/end), so the start/end comparison is seen
    # in context of the whole staircase. The fit line's slope can run well
    # off the top of that range (especially when a lumpy cost like Building
    # is treated as Variable) -- coord_cartesian() crops the view to the
    # true curve's own range without dropping any of the underlying data,
    # so the line still draws correctly, just partly off-screen.
    # Prepend a (0 students, $0) point so the very first step -- the school
    # opening, its initial 6 teachers, and the first student's supplies, all
    # incurred the instant student #1 arrives -- actually renders as a
    # visible vertical jump at the left edge, instead of the plot's data
    # simply starting mid-air at the row-1 cost.
    full_df <- rbind(
      data.table(students = 0, total = 0),
      data.table(students = sim$students, total = total_cum)
    )

    # Decompose the fit line into its three components, stacked the same
    # order as the real Building/Supplies/Teacher ribbons elsewhere in the
    # app (building at bottom, teachers on top), so the top edge of the
    # stack traces out exactly the same line the single dashed abline used
    # to. Drawn with heavy transparency and a dashed border (rather than
    # the solid fills used for real costs) specifically so it reads as a
    # model, not actual spending.
    model_x <- full_df$students
    building_model <- if (input$mc_building_choice == "Variable") {
      (mc_school_cost / mc_high_capacity_per_school) * model_x
    } else {
      rep(building_at_start, length(model_x))
    }
    supplies_model <- if (input$mc_supplies_choice == "Variable") {
      mc_supply_rate * model_x
    } else {
      rep(mc_supply_rate * start, length(model_x))
    }
    teacher_model <- if (input$mc_teacher_choice == "Variable") {
      (mc_teacher_cost / mc_teacher_capacity) * model_x
    } else {
      rep(teacher_at_start, length(model_x))
    }

    model_long <- rbind(
      data.table(
        students = model_x,
        ymin = 0,
        ymax = building_model,
        component = "Building expense"
      ),
      data.table(
        students = model_x,
        ymin = building_model,
        ymax = building_model + supplies_model,
        component = "School supplies"
      ),
      data.table(
        students = model_x,
        ymin = building_model + supplies_model,
        ymax = building_model + supplies_model + teacher_model,
        component = "Teacher salaries"
      )
    )
    model_long[,
      component := factor(
        component,
        levels = c("Building expense", "School supplies", "Teacher salaries")
      )
    ]

    # The four comparison markers -- true vs. modeled cost, at the current
    # vs. changed enrollment -- are all plotted through a single geom_point
    # layer with `shape` mapped to a factor, so ggplot builds one legend
    # ("key") automatically instead of relying on unlabeled annotate() calls.
    # Everything is drawn in the same red so the shape (open/closed,
    # circle/diamond) is the only thing distinguishing them. Note this
    # deliberately avoids also mapping fill/color here, since those
    # aesthetics are already claimed by the ribbon's Building/Supplies/
    # Teacher scales above -- mapping them again would silently overwrite
    # that scale.
    marker_levels <- c(
      "Modeled cost, current enrollment",
      "Modeled cost, changed enrollment",
      "True cost, current enrollment",
      "True cost, changed enrollment"
    )
    markers <- data.table(
      kind = factor(marker_levels, levels = marker_levels),
      x = c(start, end, start, end),
      y = c(model_start, model_end, true_start, true_end)
    )

    # A solid, reasonably opaque fill with a bold dashed outline keeps the
    # three bands clearly distinct without a busy texture -- the dashed
    # border is the same "this is a model, not real spending" cue used
    # elsewhere in the app (e.g. the old fitted-line style), just applied
    # per band instead of to a single line.
    ggplot(full_df, aes(x = students, y = total)) +
      geom_ribbon(
        data = model_long,
        aes(
          x = students,
          ymin = ymin,
          ymax = ymax,
          fill = component,
          color = component
        ),
        inherit.aes = FALSE,
        alpha = 0.42,
        linewidth = 0.9,
        linetype = "dashed"
      ) +
      scale_fill_manual(
        values = c(
          "Building expense" = palette_cb[["ink"]],
          "School supplies" = palette_cb[["facility"]],
          "Teacher salaries" = palette_cb[["highlow"]]
        ),
        guide = "none"
      ) +
      scale_color_manual(
        values = c(
          "Building expense" = palette_cb[["ink"]],
          "School supplies" = palette_cb[["facility"]],
          "Teacher salaries" = palette_cb[["highlow"]]
        ),
        guide = "none"
      ) +
      geom_step(
        direction = "vh",
        color = palette_cb[["ink"]],
        linewidth = 0.7
      ) +
      # A concave arrow connecting the start and end points directly -- bowed
      # well clear of the true-cost staircase (which sits at or below the
      # straight chord between these two points) so it reads as a distinct
      # "look here" annotation rather than part of the data. Negative
      # curvature bows this particular left-to-right, upward chord above
      # itself -- away from the step line below it -- rather than sagging
      # down toward/through it.
      annotate(
        "segment",
        x = start,
        xend = start,
        y = true_start,
        yend = model_start,
        color = "#D7263D",
        linewidth = 0.9,
        linetype = "dotted"
      ) +
      annotate(
        "segment",
        x = end,
        xend = end,
        y = true_end,
        yend = model_end,
        color = "#D7263D",
        linewidth = 0.9,
        linetype = "dotted"
      ) +
      geom_point(
        data = markers,
        aes(x = x, y = y, shape = kind),
        inherit.aes = FALSE,
        color = "#D7263D",
        size = 3.6,
        stroke = 1.4
      ) +
      scale_shape_manual(
        name = "Markers",
        values = c(
          "Modeled cost, current enrollment" = 5,
          "Modeled cost, changed enrollment" = 18,
          "True cost, current enrollment" = 1,
          "True cost, changed enrollment" = 16
        )
      ) +
      coord_cartesian(
        xlim = c(0, nrow(sim)),
        ylim = c(0, max(total_cum) * 1.12)
      ) +
      scale_x_continuous(labels = comma) +
      scale_y_continuous(labels = comma) +
      labs(
        title = paste0(
          "High School Total Cost, Full Enrollment Range (0-",
          format(nrow(sim), big.mark = ","),
          " Students)"
        ),
        subtitle = paste0(
          "Navy line = true step cost   |   Shaded bands (dashed border) = your ",
          "fitted model, decomposed into Building/Supplies/Teacher components ",
          "at ",
          format(start, big.mark = ","),
          "   |   Red dotted lines = ",
          "error between true and modeled cost at ",
          format(start, big.mark = ","),
          " and ",
          format(end, big.mark = ","),
          " students   |   See key for markers"
        ),
        x = "Students Enrolled",
        y = "Total Cost ($)"
      ) +
      theme_minimal(base_size = 13) +
      theme(legend.position = "bottom")
  })

  output$modelChoiceStats <- renderUI({
    sim <- highSim()$trace
    start <- input$mc_start
    delta <- input$mc_delta
    end <- start + delta
    validate(need(nrow(sim) >= end, ""))

    mc_school_cost <- input$mc_school_cost
    mc_supply_rate <- input$mc_supply_rate
    mc_teacher_cost <- input$mc_teacher_cost
    mc_teacher_capacity <- input$mc_teacher_capacity
    validate(need(
      !is.na(mc_school_cost) &&
        !is.na(mc_supply_rate) &&
        !is.na(mc_teacher_cost) &&
        !is.na(mc_teacher_capacity) &&
        mc_school_cost >= 0 &&
        mc_supply_rate >= 0 &&
        mc_teacher_cost >= 0 &&
        mc_teacher_capacity >= 1,
      ""
    ))

    mc_teacher_student_capacity <- mc_teacher_capacity * teacher_classes_per_day
    mc_high_capacity_per_school <- floor(
      high_classrooms_per_school / length(subjects)
    ) *
      mc_teacher_student_capacity

    building_cum <- rep(mc_school_cost, nrow(sim))
    supplies_cum <- sim$students * mc_supply_rate
    teacher_cum <- sim$teachers * mc_teacher_cost
    total_cum <- building_cum + supplies_cum + teacher_cum

    building_at_start <- idx_or_zero(building_cum, start)
    teacher_at_start <- idx_or_zero(teacher_cum, start)
    true_start <- idx_or_zero(total_cum, start)
    true_end <- idx_or_zero(total_cum, end)

    fixed_part <- 0
    var_rate <- 0
    if (input$mc_supplies_choice == "Variable") {
      var_rate <- var_rate + mc_supply_rate
    } else {
      fixed_part <- fixed_part + mc_supply_rate * start
    }
    if (input$mc_teacher_choice == "Variable") {
      var_rate <- var_rate + mc_teacher_cost / mc_teacher_capacity
    } else {
      fixed_part <- fixed_part + teacher_at_start
    }
    if (input$mc_building_choice == "Variable") {
      var_rate <- var_rate + mc_school_cost / mc_high_capacity_per_school
    } else {
      fixed_part <- fixed_part + building_at_start
    }

    model_end <- fixed_part + var_rate * end
    model_start <- fixed_part + var_rate * start

    true_change <- true_end - true_start
    model_change <- model_end - model_start
    error <- model_change - true_change
    pct_error <- if (true_change != 0) 100 * error / true_change else NA

    dollar <- function(v) {
      paste0("$", format(round(v), big.mark = ",", scientific = FALSE))
    }

    # Spell out exactly what's inside the fixed amount and the slope, so
    # "TC = fixed + slope x Students" isn't just two abstract numbers --
    # e.g. "3 teachers x $80,000 = $240,000" for a Fixed teacher cost, or
    # "$80,000/teacher / 25 students/section = $3,200/student" for a
    # Variable one.
    n_buildings <- if (mc_school_cost > 0) {
      round(building_at_start / mc_school_cost)
    } else {
      0
    }
    n_teachers <- if (mc_teacher_cost > 0) {
      round(teacher_at_start / mc_teacher_cost)
    } else {
      0
    }

    fixed_items <- c()
    if (input$mc_building_choice == "Fixed") {
      fixed_items <- c(
        fixed_items,
        paste0(
          format(n_buildings, big.mark = ","),
          " building",
          if (n_buildings != 1) "s" else "",
          " &times; ",
          dollar(mc_school_cost),
          " = ",
          dollar(building_at_start)
        )
      )
    }
    if (input$mc_teacher_choice == "Fixed") {
      fixed_items <- c(
        fixed_items,
        paste0(
          format(n_teachers, big.mark = ","),
          " teacher",
          if (n_teachers != 1) "s" else "",
          " &times; ",
          dollar(mc_teacher_cost),
          " = ",
          dollar(teacher_at_start)
        )
      )
    }
    if (input$mc_supplies_choice == "Fixed") {
      fixed_items <- c(
        fixed_items,
        paste0(
          format(start, big.mark = ","),
          " students &times; ",
          dollar(mc_supply_rate),
          "/student = ",
          dollar(mc_supply_rate * start)
        )
      )
    }
    fixed_desc <- if (length(fixed_items) > 0) {
      paste0(
        "<ul style='margin:2px 0 2px 0; padding-left:20px;'>",
        paste0("<li>", fixed_items, "</li>", collapse = ""),
        "</ul>"
      )
    } else {
      " none -- every cost is classified as Variable<br>"
    }

    var_items <- c()
    if (input$mc_supplies_choice == "Variable") {
      var_items <- c(
        var_items,
        paste0(dollar(mc_supply_rate), "/student (supplies)")
      )
    }
    if (input$mc_teacher_choice == "Variable") {
      teacher_rate <- if (mc_teacher_capacity > 0) {
        mc_teacher_cost / mc_teacher_capacity
      } else {
        0
      }
      var_items <- c(
        var_items,
        paste0(
          dollar(mc_teacher_cost),
          "/teacher &divide; ",
          format(mc_teacher_capacity, big.mark = ","),
          " students/section = ",
          dollar(teacher_rate),
          "/student (teachers)"
        )
      )
    }
    if (input$mc_building_choice == "Variable") {
      building_rate <- if (mc_high_capacity_per_school > 0) {
        mc_school_cost / mc_high_capacity_per_school
      } else {
        0
      }
      var_items <- c(
        var_items,
        paste0(
          dollar(mc_school_cost),
          "/school &divide; ",
          format(round(mc_high_capacity_per_school), big.mark = ","),
          "-student capacity = ",
          dollar(building_rate),
          "/student (building)"
        )
      )
    }
    var_desc <- if (length(var_items) > 0) {
      paste0(
        "<ul style='margin:2px 0 2px 0; padding-left:20px;'>",
        paste0("<li>", var_items, "</li>", collapse = ""),
        "</ul>"
      )
    } else {
      " none -- every cost is classified as Fixed<br>"
    }

    HTML(paste0(
      "<div style='font-size:15px; line-height:1.6;'>",
      "<b>Your model:</b> TC = $",
      format(round(fixed_part), big.mark = ",", scientific = FALSE),
      " + $",
      format(round(var_rate, 2), big.mark = ",", scientific = FALSE),
      " &times; Students<br>",
      "<div style='font-size:13px; color:#444; margin: 4px 0 10px 0;'>",
      "<b>Fixed costs:</b>",
      fixed_desc,
      "<b>Variable costs (slope):</b>",
      var_desc,
      "</div>",
      "<table style='border-collapse:collapse;'>",
      "<tr><td style='padding:2px 24px 2px 0;'><b>True cost at starting enrollment</b> (",
      format(start, big.mark = ","),
      " students)</td><td>",
      dollar(true_start),
      "</td></tr>",
      "<tr><td style='padding:2px 24px 2px 0;'><b>True cost at ending enrollment</b> (",
      format(end, big.mark = ","),
      " students)</td><td>",
      dollar(true_end),
      "</td></tr>",
      "<tr><td style='padding:2px 24px 2px 0;'><b>True change</b></td><td>",
      dollar(true_change),
      "</td></tr>",
      "<tr><td style='padding:10px 24px 2px 0;'><b>Modeled cost at start</b></td><td style='padding-top:10px;'>",
      dollar(model_start),
      "</td></tr>",
      "<tr><td style='padding:2px 24px 2px 0;'><b>Modeled cost at end</b></td><td>",
      dollar(model_end),
      "</td></tr>",
      "<tr><td style='padding:2px 24px 2px 0;'><b>Modeled change</b></td><td>",
      dollar(model_change),
      "</td></tr>",
      "</table><br>",
      "<b>Error (modeled change vs. true change):</b> ",
      dollar(error),
      if (!is.na(pct_error)) paste0(" (", round(pct_error, 1), "%)") else "",
      "</div>"
    ))
  })

  ##############################################################################
  # "6. Modeling Choices: District" tab server logic. Mirrors the High
  # School Modeling Choices tab above, but the true cost is now the sum of
  # THREE independently-growing bands (elementary/middle/high), each with
  # its own building capacity and its own school-opening cadence. This
  # reactive is self-contained (its own seed + Refresh button) rather than
  # sharing state with the "4. District" tab, since that tab's own trace is
  # keyed to a 0-20,000 range slider rather than a fixed range.
  ##############################################################################

  # districtSimMC is driven by an explicit counter (rather than directly by
  # input$generate_body_district_mc) so that BOTH the Refresh button and the
  # Reset Defaults button can force a fresh trace -- including when Reset
  # sets the seed back to 1 but it was already 1, which wouldn't otherwise
  # register as a change worth re-triggering on.
  districtMCTrigger <- reactiveVal(0)
  districtMCSeedValue <- reactiveVal(1)

  observeEvent(input$generate_body_district_mc, {
    districtMCSeedValue(input$rand_seed_district_mc)
    districtMCTrigger(districtMCTrigger() + 1)
  })

  observeEvent(input$mc2_reset_defaults, {
    updateSliderInput(session, "mc2_start", value = 10000)
    updateSliderInput(session, "mc2_delta", value = 1000)
    updateSliderInput(session, "mc2_view_range", value = c(7000, 12000))
    updateNumericInput(session, "mc2_school_cost", value = school_cost)
    updateNumericInput(session, "mc2_supply_rate", value = supply_rate)
    updateNumericInput(session, "mc2_teacher_cost", value = teacher_cost)
    updateNumericInput(
      session,
      "mc2_teacher_capacity",
      value = teacher_capacity
    )
    updateNumericInput(
      session,
      "mc2_elem_teacher_capacity",
      value = teacher_capacity
    )
    updateNumericInput(
      session,
      "mc2_elem_school_capacity",
      value = elem_classrooms_per_grade_cap *
        teacher_capacity *
        length(elem_grades)
    )
    updateNumericInput(
      session,
      "mc2_mid_school_capacity",
      value = middle_capacity_per_school
    )
    updateNumericInput(
      session,
      "mc2_high_school_capacity",
      value = high_capacity_per_school
    )
    updateRadioButtons(session, "mc2_building_choice", selected = "Variable")
    updateRadioButtons(session, "mc2_supplies_choice", selected = "Variable")
    updateRadioButtons(session, "mc2_teacher_choice", selected = "Variable")
    updateNumericInput(session, "rand_seed_district_mc", value = 1)
    districtMCSeedValue(1)
    districtMCTrigger(districtMCTrigger() + 1)
  })

  districtSimMC <- eventReactive(
    districtMCTrigger(),
    {
      seed <- districtMCSeedValue()
      max_n <- district_mc_max_n

      set.seed(seed)
      draws <- sample(grade_levels, max_n, replace = TRUE)

      ind <- sapply(grade_levels, function(g) as.integer(draws == g))
      cum_counts <- apply(ind, 2, cumsum)
      colnames(cum_counts) <- grade_levels

      elem_pos_vec <- rowSums(cum_counts[, elem_grades, drop = FALSE])
      mid_pos_vec <- rowSums(cum_counts[, middle_grades, drop = FALSE])
      high_pos_vec <- rowSums(cum_counts[, high_grades, drop = FALSE])

      elem_trace <- simulate_multi_elem(draws[draws %in% elem_grades])
      mid_trace <- simulate_multi_secondary(
        draws[draws %in% middle_grades],
        middle_grades,
        middle_classrooms_per_school
      )
      high_trace <- simulate_multi_secondary(
        draws[draws %in% high_grades],
        high_grades,
        high_classrooms_per_school
      )

      elem_teachers_vec <- band_lookup(elem_trace, elem_pos_vec, "teachers")
      elem_schools_vec <- band_lookup(elem_trace, elem_pos_vec, "schools")
      mid_teachers_vec <- band_lookup(mid_trace, mid_pos_vec, "teachers")
      mid_schools_vec <- band_lookup(mid_trace, mid_pos_vec, "schools")
      high_teachers_vec <- band_lookup(high_trace, high_pos_vec, "teachers")
      high_schools_vec <- band_lookup(high_trace, high_pos_vec, "schools")

      data.table(
        students = seq_len(max_n),
        total_schools = elem_schools_vec + mid_schools_vec + high_schools_vec,
        total_teachers = elem_teachers_vec +
          mid_teachers_vec +
          high_teachers_vec,
        elem_schools = elem_schools_vec,
        mid_schools = mid_schools_vec,
        high_schools = high_schools_vec,
        elem_teachers = elem_teachers_vec,
        mid_teachers = mid_teachers_vec,
        high_teachers = high_teachers_vec
      )
    },
    ignoreNULL = FALSE,
    ignoreInit = FALSE
  )

  # Same idea as the High School tab's equivalent observer above: keeps the
  # district "Change in enrollment" slider's range tied to the starting
  # enrollment, so the ending enrollment always stays within 0 and the
  # district's full traced enrollment, while still allowing decreases.
  observe({
    cap <- nrow(districtSimMC())
    lo <- -input$mc2_start
    hi <- max(lo, cap - input$mc2_start)
    updateSliderInput(
      session,
      "mc2_delta",
      min = lo,
      max = hi,
      value = min(max(input$mc2_delta, lo), hi)
    )
  })

  output$modelChoicePlotDistrict <- renderPlot({
    dsim <- districtSimMC()
    start <- input$mc2_start
    delta <- input$mc2_delta
    end <- start + delta

    validate(need(
      nrow(dsim) >= end,
      paste0(
        "The current district draw only admits ",
        nrow(dsim),
        " students -- lower the starting enrollment or change in ",
        "enrollment, or generate a new draw."
      )
    ))

    view_range <- input$mc2_view_range
    validate(need(
      !is.null(view_range) &&
        length(view_range) == 2 &&
        view_range[2] > view_range[1],
      "Widen the plot view range slider -- the minimum can't equal the maximum."
    ))
    view_lo <- max(0, view_range[1])
    view_hi <- min(nrow(dsim), view_range[2])

    mc2_school_cost <- input$mc2_school_cost
    mc2_supply_rate <- input$mc2_supply_rate
    mc2_teacher_cost <- input$mc2_teacher_cost
    mc2_teacher_capacity <- input$mc2_teacher_capacity
    mc2_elem_teacher_capacity <- input$mc2_elem_teacher_capacity
    mc2_elem_school_capacity <- input$mc2_elem_school_capacity
    mc2_mid_school_capacity <- input$mc2_mid_school_capacity
    mc2_high_school_capacity <- input$mc2_high_school_capacity
    validate(need(
      !is.na(mc2_school_cost) &&
        !is.na(mc2_supply_rate) &&
        !is.na(mc2_teacher_cost) &&
        !is.na(mc2_teacher_capacity) &&
        !is.na(mc2_elem_teacher_capacity) &&
        !is.na(mc2_elem_school_capacity) &&
        !is.na(mc2_mid_school_capacity) &&
        !is.na(mc2_high_school_capacity) &&
        mc2_school_cost >= 0 &&
        mc2_supply_rate >= 0 &&
        mc2_teacher_cost >= 0 &&
        mc2_teacher_capacity >= 1 &&
        mc2_elem_teacher_capacity >= 1 &&
        mc2_elem_school_capacity >= 1 &&
        mc2_mid_school_capacity >= 1 &&
        mc2_high_school_capacity >= 1,
      "Cost assumptions must be non-negative, and capacities must be at least 1."
    ))

    # The district builds three different kinds of schools -- and staffs
    # elementary classrooms differently from middle/high sections -- so a
    # single "Variable" building or teacher rate has to blend each type's
    # own capacity, weighted by how many of each type actually exist at
    # the end enrollment, into one $/student figure.
    n_elem <- idx_or_zero(dsim$elem_schools, end)
    n_mid <- idx_or_zero(dsim$mid_schools, end)
    n_high <- idx_or_zero(dsim$high_schools, end)
    n_tot <- n_elem + n_mid + n_high
    mc2_avg_capacity_per_school <- if (n_tot > 0) {
      (n_elem *
        mc2_elem_school_capacity +
        n_mid * mc2_mid_school_capacity +
        n_high * mc2_high_school_capacity) /
        n_tot
    } else {
      (mc2_elem_school_capacity +
        mc2_mid_school_capacity +
        mc2_high_school_capacity) /
        3
    }

    n_elem_teachers <- idx_or_zero(dsim$elem_teachers, end)
    n_mh_teachers <- idx_or_zero(dsim$mid_teachers, end) +
      idx_or_zero(dsim$high_teachers, end)
    n_teach_tot <- n_elem_teachers + n_mh_teachers
    mc2_teacher_rate <- if (n_teach_tot > 0) {
      (n_elem_teachers *
        (mc2_teacher_cost / mc2_elem_teacher_capacity) +
        n_mh_teachers * (mc2_teacher_cost / mc2_teacher_capacity)) /
        n_teach_tot
    } else {
      (mc2_teacher_cost /
        mc2_elem_teacher_capacity +
        mc2_teacher_cost / mc2_teacher_capacity) /
        2
    }

    building_cum <- dsim$total_schools * mc2_school_cost
    supplies_cum <- dsim$students * mc2_supply_rate
    teacher_cum <- dsim$total_teachers * mc2_teacher_cost
    total_cum <- building_cum + supplies_cum + teacher_cum

    # Scale the y-axis to whatever's actually visible in the chosen view
    # window, rather than the full 0-20,000 range, so zooming in on a
    # narrow window (e.g. the 7,000-12,000 default) doesn't leave the
    # curve squashed near the bottom of the plot.
    visible_idx <- which(dsim$students >= view_lo & dsim$students <= view_hi)
    y_max_visible <- if (length(visible_idx) > 0) {
      max(total_cum[visible_idx])
    } else {
      max(total_cum)
    }

    building_at_start <- idx_or_zero(building_cum, start)
    teacher_at_start <- idx_or_zero(teacher_cum, start)
    true_start <- idx_or_zero(total_cum, start)
    true_end <- idx_or_zero(total_cum, end)

    fixed_part <- 0
    var_rate <- 0
    if (input$mc2_supplies_choice == "Variable") {
      var_rate <- var_rate + mc2_supply_rate
    } else {
      fixed_part <- fixed_part + mc2_supply_rate * start
    }
    if (input$mc2_teacher_choice == "Variable") {
      var_rate <- var_rate + mc2_teacher_rate
    } else {
      fixed_part <- fixed_part + teacher_at_start
    }
    if (input$mc2_building_choice == "Variable") {
      var_rate <- var_rate + mc2_school_cost / mc2_avg_capacity_per_school
    } else {
      fixed_part <- fixed_part + building_at_start
    }

    model_end <- fixed_part + var_rate * end
    model_start <- fixed_part + var_rate * start

    full_df <- rbind(
      data.table(students = 0, total = 0),
      data.table(students = dsim$students, total = total_cum)
    )

    model_x <- full_df$students
    building_model <- if (input$mc2_building_choice == "Variable") {
      (mc2_school_cost / mc2_avg_capacity_per_school) * model_x
    } else {
      rep(building_at_start, length(model_x))
    }
    supplies_model <- if (input$mc2_supplies_choice == "Variable") {
      mc2_supply_rate * model_x
    } else {
      rep(mc2_supply_rate * start, length(model_x))
    }
    teacher_model <- if (input$mc2_teacher_choice == "Variable") {
      mc2_teacher_rate * model_x
    } else {
      rep(teacher_at_start, length(model_x))
    }

    model_long <- rbind(
      data.table(
        students = model_x,
        ymin = 0,
        ymax = building_model,
        component = "Building expense"
      ),
      data.table(
        students = model_x,
        ymin = building_model,
        ymax = building_model + supplies_model,
        component = "School supplies"
      ),
      data.table(
        students = model_x,
        ymin = building_model + supplies_model,
        ymax = building_model + supplies_model + teacher_model,
        component = "Teacher salaries"
      )
    )
    model_long[,
      component := factor(
        component,
        levels = c("Building expense", "School supplies", "Teacher salaries")
      )
    ]

    marker_levels <- c(
      "Modeled cost, current enrollment",
      "Modeled cost, changed enrollment",
      "True cost, current enrollment",
      "True cost, changed enrollment"
    )
    markers <- data.table(
      kind = factor(marker_levels, levels = marker_levels),
      x = c(start, end, start, end),
      y = c(model_start, model_end, true_start, true_end)
    )

    ggplot(full_df, aes(x = students, y = total)) +
      geom_ribbon(
        data = model_long,
        aes(
          x = students,
          ymin = ymin,
          ymax = ymax,
          fill = component,
          color = component
        ),
        inherit.aes = FALSE,
        alpha = 0.42,
        linewidth = 0.9,
        linetype = "dashed"
      ) +
      scale_fill_manual(
        values = c(
          "Building expense" = palette_cb[["ink"]],
          "School supplies" = palette_cb[["facility"]],
          "Teacher salaries" = palette_cb[["highlow"]]
        ),
        guide = "none"
      ) +
      scale_color_manual(
        values = c(
          "Building expense" = palette_cb[["ink"]],
          "School supplies" = palette_cb[["facility"]],
          "Teacher salaries" = palette_cb[["highlow"]]
        ),
        guide = "none"
      ) +
      geom_step(
        direction = "vh",
        color = palette_cb[["ink"]],
        linewidth = 0.7
      ) +
      annotate(
        "segment",
        x = start,
        xend = start,
        y = true_start,
        yend = model_start,
        color = "#D7263D",
        linewidth = 0.9,
        linetype = "dotted"
      ) +
      annotate(
        "segment",
        x = end,
        xend = end,
        y = true_end,
        yend = model_end,
        color = "#D7263D",
        linewidth = 0.9,
        linetype = "dotted"
      ) +
      geom_point(
        data = markers,
        aes(x = x, y = y, shape = kind),
        inherit.aes = FALSE,
        color = "#D7263D",
        size = 3.6,
        stroke = 1.4
      ) +
      scale_shape_manual(
        name = "Markers",
        values = c(
          "Modeled cost, current enrollment" = 5,
          "Modeled cost, changed enrollment" = 18,
          "True cost, current enrollment" = 1,
          "True cost, changed enrollment" = 16
        )
      ) +
      coord_cartesian(
        xlim = c(view_lo, view_hi),
        ylim = c(0, y_max_visible * 1.12)
      ) +
      scale_x_continuous(labels = comma) +
      scale_y_continuous(labels = comma) +
      labs(
        title = paste0(
          "District Total Cost, ",
          format(view_lo, big.mark = ","),
          "-",
          format(view_hi, big.mark = ","),
          " Students"
        ),
        subtitle = paste0(
          "Navy line = true step cost   |   Shaded bands (dashed border) = your ",
          "fitted model, decomposed into Building/Supplies/Teacher components ",
          "at ",
          format(start, big.mark = ","),
          "   |   Red dotted lines = ",
          "error between true and modeled cost at ",
          format(start, big.mark = ","),
          " and ",
          format(end, big.mark = ","),
          " students   |   See key for markers"
        ),
        x = "Students Enrolled",
        y = "Total Cost ($)"
      ) +
      theme_minimal(base_size = 13) +
      theme(legend.position = "bottom")
  })

  output$modelChoiceStatsDistrict <- renderUI({
    dsim <- districtSimMC()
    start <- input$mc2_start
    delta <- input$mc2_delta
    end <- start + delta
    validate(need(nrow(dsim) >= end, ""))

    mc2_school_cost <- input$mc2_school_cost
    mc2_supply_rate <- input$mc2_supply_rate
    mc2_teacher_cost <- input$mc2_teacher_cost
    mc2_teacher_capacity <- input$mc2_teacher_capacity
    mc2_elem_teacher_capacity <- input$mc2_elem_teacher_capacity
    mc2_elem_school_capacity <- input$mc2_elem_school_capacity
    mc2_mid_school_capacity <- input$mc2_mid_school_capacity
    mc2_high_school_capacity <- input$mc2_high_school_capacity
    validate(need(
      !is.na(mc2_school_cost) &&
        !is.na(mc2_supply_rate) &&
        !is.na(mc2_teacher_cost) &&
        !is.na(mc2_teacher_capacity) &&
        !is.na(mc2_elem_teacher_capacity) &&
        !is.na(mc2_elem_school_capacity) &&
        !is.na(mc2_mid_school_capacity) &&
        !is.na(mc2_high_school_capacity) &&
        mc2_school_cost >= 0 &&
        mc2_supply_rate >= 0 &&
        mc2_teacher_cost >= 0 &&
        mc2_teacher_capacity >= 1 &&
        mc2_elem_teacher_capacity >= 1 &&
        mc2_elem_school_capacity >= 1 &&
        mc2_mid_school_capacity >= 1 &&
        mc2_high_school_capacity >= 1,
      ""
    ))

    n_elem <- idx_or_zero(dsim$elem_schools, end)
    n_mid <- idx_or_zero(dsim$mid_schools, end)
    n_high <- idx_or_zero(dsim$high_schools, end)
    n_tot <- n_elem + n_mid + n_high
    mc2_avg_capacity_per_school <- if (n_tot > 0) {
      (n_elem *
        mc2_elem_school_capacity +
        n_mid * mc2_mid_school_capacity +
        n_high * mc2_high_school_capacity) /
        n_tot
    } else {
      (mc2_elem_school_capacity +
        mc2_mid_school_capacity +
        mc2_high_school_capacity) /
        3
    }

    n_elem_teachers <- idx_or_zero(dsim$elem_teachers, end)
    n_mh_teachers <- idx_or_zero(dsim$mid_teachers, end) +
      idx_or_zero(dsim$high_teachers, end)
    n_teach_tot <- n_elem_teachers + n_mh_teachers
    mc2_teacher_rate <- if (n_teach_tot > 0) {
      (n_elem_teachers *
        (mc2_teacher_cost / mc2_elem_teacher_capacity) +
        n_mh_teachers * (mc2_teacher_cost / mc2_teacher_capacity)) /
        n_teach_tot
    } else {
      (mc2_teacher_cost /
        mc2_elem_teacher_capacity +
        mc2_teacher_cost / mc2_teacher_capacity) /
        2
    }

    building_cum <- dsim$total_schools * mc2_school_cost
    supplies_cum <- dsim$students * mc2_supply_rate
    teacher_cum <- dsim$total_teachers * mc2_teacher_cost
    total_cum <- building_cum + supplies_cum + teacher_cum

    building_at_start <- idx_or_zero(building_cum, start)
    teacher_at_start <- idx_or_zero(teacher_cum, start)
    true_start <- idx_or_zero(total_cum, start)
    true_end <- idx_or_zero(total_cum, end)

    fixed_part <- 0
    var_rate <- 0
    if (input$mc2_supplies_choice == "Variable") {
      var_rate <- var_rate + mc2_supply_rate
    } else {
      fixed_part <- fixed_part + mc2_supply_rate * start
    }
    if (input$mc2_teacher_choice == "Variable") {
      var_rate <- var_rate + mc2_teacher_rate
    } else {
      fixed_part <- fixed_part + teacher_at_start
    }
    if (input$mc2_building_choice == "Variable") {
      var_rate <- var_rate + mc2_school_cost / mc2_avg_capacity_per_school
    } else {
      fixed_part <- fixed_part + building_at_start
    }

    model_end <- fixed_part + var_rate * end
    model_start <- fixed_part + var_rate * start

    true_change <- true_end - true_start
    model_change <- model_end - model_start
    error <- model_change - true_change
    pct_error <- if (true_change != 0) 100 * error / true_change else NA

    dollar <- function(v) {
      paste0("$", format(round(v), big.mark = ",", scientific = FALSE))
    }

    # Same breakdown as the High School tab, but the Fixed building line
    # also splits the count out by school type (elementary/middle/high),
    # since a district can be building all three at once, and the Variable
    # building line uses the blended average capacity computed above.
    n_elem_start <- idx_or_zero(dsim$elem_schools, start)
    n_mid_start <- idx_or_zero(dsim$mid_schools, start)
    n_high_start <- idx_or_zero(dsim$high_schools, start)
    n_buildings <- n_elem_start + n_mid_start + n_high_start
    n_teachers <- if (mc2_teacher_cost > 0) {
      round(teacher_at_start / mc2_teacher_cost)
    } else {
      0
    }

    fixed_items <- c()
    if (input$mc2_building_choice == "Fixed") {
      fixed_items <- c(
        fixed_items,
        paste0(
          n_elem_start,
          " elementary + ",
          n_mid_start,
          " middle + ",
          n_high_start,
          " high = ",
          format(n_buildings, big.mark = ","),
          " building",
          if (n_buildings != 1) "s" else "",
          " &times; ",
          dollar(mc2_school_cost),
          " = ",
          dollar(building_at_start)
        )
      )
    }
    if (input$mc2_teacher_choice == "Fixed") {
      fixed_items <- c(
        fixed_items,
        paste0(
          format(n_teachers, big.mark = ","),
          " teacher",
          if (n_teachers != 1) "s" else "",
          " &times; ",
          dollar(mc2_teacher_cost),
          " = ",
          dollar(teacher_at_start)
        )
      )
    }
    if (input$mc2_supplies_choice == "Fixed") {
      fixed_items <- c(
        fixed_items,
        paste0(
          format(start, big.mark = ","),
          " students &times; ",
          dollar(mc2_supply_rate),
          "/student = ",
          dollar(mc2_supply_rate * start)
        )
      )
    }
    fixed_desc <- if (length(fixed_items) > 0) {
      paste0(
        "<ul style='margin:2px 0 2px 0; padding-left:20px;'>",
        paste0("<li>", fixed_items, "</li>", collapse = ""),
        "</ul>"
      )
    } else {
      " none -- every cost is classified as Variable<br>"
    }

    var_items <- c()
    if (input$mc2_supplies_choice == "Variable") {
      var_items <- c(
        var_items,
        paste0(dollar(mc2_supply_rate), "/student (supplies)")
      )
    }
    if (input$mc2_teacher_choice == "Variable") {
      var_items <- c(
        var_items,
        paste0(
          dollar(mc2_teacher_cost),
          "/teacher, blended across ",
          format(mc2_elem_teacher_capacity, big.mark = ","),
          " students/elementary teacher and ",
          format(mc2_teacher_capacity, big.mark = ","),
          " students/section (middle/high) = ",
          dollar(mc2_teacher_rate),
          "/student (teachers)"
        )
      )
    }
    if (input$mc2_building_choice == "Variable") {
      building_rate <- if (mc2_avg_capacity_per_school > 0) {
        mc2_school_cost / mc2_avg_capacity_per_school
      } else {
        0
      }
      var_items <- c(
        var_items,
        paste0(
          dollar(mc2_school_cost),
          "/school &divide; ",
          format(round(mc2_avg_capacity_per_school), big.mark = ","),
          "-student blended average capacity = ",
          dollar(building_rate),
          "/student (building)"
        )
      )
    }
    var_desc <- if (length(var_items) > 0) {
      paste0(
        "<ul style='margin:2px 0 2px 0; padding-left:20px;'>",
        paste0("<li>", var_items, "</li>", collapse = ""),
        "</ul>"
      )
    } else {
      " none -- every cost is classified as Fixed<br>"
    }

    HTML(paste0(
      "<div style='font-size:15px; line-height:1.6;'>",
      "<b>Your model:</b> TC = $",
      format(round(fixed_part), big.mark = ",", scientific = FALSE),
      " + $",
      format(round(var_rate, 2), big.mark = ",", scientific = FALSE),
      " &times; Students<br>",
      "<div style='font-size:13px; color:#444; margin: 4px 0 10px 0;'>",
      "<b>Fixed costs:</b>",
      fixed_desc,
      "<b>Variable costs (slope):</b>",
      var_desc,
      "</div>",
      "<table style='border-collapse:collapse;'>",
      "<tr><td style='padding:2px 24px 2px 0;'><b>True cost at starting enrollment</b> (",
      format(start, big.mark = ","),
      " students)</td><td>",
      dollar(true_start),
      "</td></tr>",
      "<tr><td style='padding:2px 24px 2px 0;'><b>True cost at ending enrollment</b> (",
      format(end, big.mark = ","),
      " students)</td><td>",
      dollar(true_end),
      "</td></tr>",
      "<tr><td style='padding:2px 24px 2px 0;'><b>True change</b></td><td>",
      dollar(true_change),
      "</td></tr>",
      "<tr><td style='padding:10px 24px 2px 0;'><b>Modeled cost at start</b></td><td style='padding-top:10px;'>",
      dollar(model_start),
      "</td></tr>",
      "<tr><td style='padding:2px 24px 2px 0;'><b>Modeled cost at end</b></td><td>",
      dollar(model_end),
      "</td></tr>",
      "<tr><td style='padding:2px 24px 2px 0;'><b>Modeled change</b></td><td>",
      dollar(model_change),
      "</td></tr>",
      "</table><br>",
      "<b>Error (modeled change vs. true change):</b> ",
      dollar(error),
      if (!is.na(pct_error)) paste0(" (", round(pct_error, 1), "%)") else "",
      "</div>"
    ))
  })

  ##############################################################################
  # District Cost Implications tab server logic (new): traces total district
  # cost -- elementary + middle + high combined -- across a chosen range of
  # student counts. Uses a vectorized cumulative-count approach (so it scales
  # to a 0-12,000+ student range without an explicit R loop), and decomposes
  # the total into the Building/Supplies/Teacher stacked-ribbon style used on
  # the Elementary and High School tabs, for visual consistency with those.
  ##############################################################################

  districtData <- eventReactive(
    input$district_run,
    {
      min_n <- input$district_range[1]
      max_n <- input$district_range[2]

      validate(
        need(
          max_n > min_n,
          "Maximum must be greater than minimum -- widen the slider range."
        )
      )

      set.seed(input$district_seed)
      draws <- sample(grade_levels, max_n, replace = TRUE)

      # cumulative count of each grade after each of the 1..max_n draws -- used
      # only to know, at every overall step, exactly how far along each band's
      # OWN building trace we are (that band's cumulative headcount so far).
      ind <- sapply(grade_levels, function(g) as.integer(draws == g))
      cum_counts <- apply(ind, 2, cumsum)
      colnames(cum_counts) <- grade_levels

      elem_pos_vec <- rowSums(cum_counts[, elem_grades, drop = FALSE])
      mid_pos_vec <- rowSums(cum_counts[, middle_grades, drop = FALSE])
      high_pos_vec <- rowSums(cum_counts[, high_grades, drop = FALSE])

      # Run each band's own multi-building simulation ONCE, in the actual
      # arrival order (true bin-packing, not a closed-form approximation),
      # then look up each band's state at every overall step.
      elem_trace <- simulate_multi_elem(draws[draws %in% elem_grades])
      mid_trace <- simulate_multi_secondary(
        draws[draws %in% middle_grades],
        middle_grades,
        middle_classrooms_per_school
      )
      high_trace <- simulate_multi_secondary(
        draws[draws %in% high_grades],
        high_grades,
        high_classrooms_per_school
      )

      elem_teachers_vec <- band_lookup(elem_trace, elem_pos_vec, "teachers")
      elem_schools_vec <- band_lookup(elem_trace, elem_pos_vec, "schools")
      mid_teachers_vec <- band_lookup(mid_trace, mid_pos_vec, "teachers")
      mid_schools_vec <- band_lookup(mid_trace, mid_pos_vec, "schools")
      high_teachers_vec <- band_lookup(high_trace, high_pos_vec, "teachers")
      high_schools_vec <- band_lookup(high_trace, high_pos_vec, "schools")

      total_teachers_vec <- elem_teachers_vec +
        mid_teachers_vec +
        high_teachers_vec
      total_schools_vec <- elem_schools_vec + mid_schools_vec + high_schools_vec
      total_students_vec <- seq_len(max_n)

      # Student counts start at 1 in the vectors above, so a minimum of 0 needs
      # a manually prepended all-zero row (an empty district costs nothing).
      idx <- max(min_n, 1):max_n
      if (min_n <= 0) {
        students <- c(0, total_students_vec[idx])
        schools <- c(0, total_schools_vec[idx])
        teachers <- c(0, total_teachers_vec[idx])
        elem_sch <- c(0, elem_schools_vec[idx])
        mid_sch <- c(0, mid_schools_vec[idx])
        high_sch <- c(0, high_schools_vec[idx])
        elem_tch <- c(0, elem_teachers_vec[idx])
        mid_tch <- c(0, mid_teachers_vec[idx])
        high_tch <- c(0, high_teachers_vec[idx])
      } else {
        students <- total_students_vec[idx]
        schools <- total_schools_vec[idx]
        teachers <- total_teachers_vec[idx]
        elem_sch <- elem_schools_vec[idx]
        mid_sch <- mid_schools_vec[idx]
        high_sch <- high_schools_vec[idx]
        elem_tch <- elem_teachers_vec[idx]
        mid_tch <- mid_teachers_vec[idx]
        high_tch <- high_teachers_vec[idx]
      }

      data.table(
        students = students,
        total_schools = schools,
        total_teachers = teachers,
        elem_schools = elem_sch,
        mid_schools = mid_sch,
        high_schools = high_sch,
        elem_teachers = elem_tch,
        mid_teachers = mid_tch,
        high_teachers = high_tch
      )
    },
    ignoreNULL = FALSE,
    ignoreInit = FALSE
  )

  # Two "events" on the Total panel, each shown as a PAIR of ovals joined
  # by an upward arrow: a bottom oval circling the jump on the dark-navy
  # Building Expense band (the actual cause of the jump), and a top oval
  # directly above it -- same x -- circling the resulting jump at the very
  # top of the Total cost curve. Both ovals in a pair share the same `key`
  # and `label`, so clicking either one highlights both and shows the same
  # callout (handled generically by flatten_district_events() below).
  districtSchoolEvents <- reactive({
    dt <- districtData()
    if (nrow(dt) < 2) {
      return(list())
    }

    building_cum <- dt$total_schools * school_cost
    supplies_cum <- dt$students * supply_rate
    teacher_cum <- dt$total_teachers * teacher_cost
    total_cum <- building_cum + supplies_cum + teacher_cum
    total_max <- max(total_cum)

    elem_jump_rows <- which(diff(c(0L, dt$elem_schools)) > 0)
    mid_jump_rows <- which(diff(c(0L, dt$mid_schools)) > 0)
    high_jump_rows <- which(diff(c(0L, dt$high_schools)) > 0)

    events <- list()
    x_pad <- max(diff(range(dt$students)) * 0.03, 40)

    make_event <- function(key, lo_row, hi_row, label) {
      cx <- (dt$students[lo_row] + dt$students[hi_row]) / 2
      rx <- (dt$students[hi_row] - dt$students[lo_row]) / 2 + x_pad

      b_before <- if (lo_row > 1) building_cum[lo_row - 1] else 0
      b_after <- building_cum[hi_row]
      b_cy <- (b_before + b_after) / 2
      b_ry <- (b_after - b_before) /
        2 +
        max((b_after - b_before) * 0.35, school_cost * 0.2)

      t_before <- if (lo_row > 1) total_cum[lo_row - 1] else 0
      t_after <- total_cum[hi_row]
      t_cy <- (t_before + t_after) / 2
      t_ry <- (t_after - t_before) /
        2 +
        max((t_after - t_before) * 0.35, total_max * 0.02)

      # Building cost is often a big fraction of total cost early on, which
      # can make these two ovals' natural sizes overlap -- leaving no room
      # for a sensible arrow between them. Shrink both proportionally
      # (same fraction, so their relative sizes are preserved) whenever
      # that would happen, guaranteeing a visible gap for the arrow.
      gap_needed <- (t_cy - b_cy) * 0.15
      overlap <- (b_cy + b_ry) - (t_cy - t_ry) + gap_needed
      if (overlap > 0 && (b_ry + t_ry) > 0) {
        shrink <- min(overlap / (b_ry + t_ry), 0.9)
        b_ry <- b_ry * (1 - shrink)
        t_ry <- t_ry * (1 - shrink)
      }

      list(
        key = key,
        label = label,
        cx = cx,
        bottom = list(cy = b_cy, rx = rx, ry = b_ry),
        top = list(cy = t_cy, rx = rx, ry = t_ry)
      )
    }

    # (1) One elementary school opening on its own (no coincident middle
    # or high school jump at that same row) -- pick one roughly in the
    # middle of the trace for a clean, clearly-visible example.
    elem_only <- elem_jump_rows[
      !(elem_jump_rows %in% mid_jump_rows) &
        !(elem_jump_rows %in% high_jump_rows)
    ]
    if (length(elem_only) == 0) {
      elem_only <- elem_jump_rows
    }
    if (length(elem_only) > 0) {
      pick <- elem_only[max(1, round(length(elem_only) / 2))]
      events <- c(
        events,
        list(make_event(
          "elem_solo",
          pick,
          pick,
          paste0(
            "New elementary school buildings are expensive enough that total costs ",
            "increase significantly with the opening of a single school (and the hiring ",
            "of a set of 6 grade-level teachers in rapid succession). As a result, the ",
            "overall costs have a distinct sloping staircase feel."
          )
        ))
      )
    }

    # (2) A spot where an elementary, middle, and high school all open
    # within a short span of enrollment (found beyond the very first such
    # cluster, so it's a coincidental later alignment rather than the
    # guaranteed start-of-enrollment one).
    if (
      length(elem_jump_rows) > 0 &&
        length(mid_jump_rows) > 0 &&
        length(high_jump_rows) > 0
    ) {
      first_triple_end <- max(
        elem_jump_rows[1],
        mid_jump_rows[1],
        high_jump_rows[1]
      )
      best <- NULL
      for (e in elem_jump_rows[elem_jump_rows > first_triple_end]) {
        m <- mid_jump_rows[which.min(abs(mid_jump_rows - e))]
        h <- high_jump_rows[which.min(abs(high_jump_rows - e))]
        spread <- max(e, m, h) - min(e, m, h)
        if (is.null(best) || spread < best$spread) {
          best <- list(e = e, m = m, h = h, spread = spread)
        }
      }
      if (!is.null(best)) {
        lo <- min(best$e, best$m, best$h)
        hi <- max(best$e, best$m, best$h)
        events <- c(
          events,
          list(make_event(
            "triple_jump",
            lo,
            hi,
            paste0(
              "The addition of a middle and high school in rapid succession on the heels ",
              "of an elementary school is readily discernible even in the total cost ",
              "roll-up. This produces a staircase pattern at a coarser interval than the ",
              "pattern resulting from the elementary school additions alone."
            )
          ))
        )
      }
    }

    events
  })

  # Unpacks the paired bottom/top event objects above into the flat
  # {key, panel, cx, cy, rx, ry, label} shape the ellipse-drawing and
  # click-hit-testing code expects -- one entry per oval, both tagged
  # with the same `key` (so a hit on either one resolves to the same
  # selection) but a unique `poly_id` (so each draws as its own polygon
  # instead of ggplot trying to connect both into one shape).
  flatten_district_events <- function(events) {
    out <- list()
    for (e in events) {
      out <- c(
        out,
        list(
          list(
            key = e$key,
            panel = "Total",
            poly_id = paste0(e$key, "_bottom"),
            cx = e$cx,
            cy = e$bottom$cy,
            rx = e$bottom$rx,
            ry = e$bottom$ry,
            label = e$label
          ),
          list(
            key = e$key,
            panel = "Total",
            poly_id = paste0(e$key, "_top"),
            cx = e$cx,
            cy = e$top$cy,
            rx = e$top$rx,
            ry = e$top$ry,
            label = e$label
          )
        )
      )
    }
    out
  }

  # Highlight ovals for the Building Expense and Teacher Salaries panels:
  # (1) the first opening of an elementary, middle, AND high school,
  # clustered near the very start of enrollment; (2) the 3rd elementary-
  # school addition, circling both its vertical jump and the flat run
  # that follows it; (3) the next middle- and high-school additions after
  # that, which tend to land close together in enrollment terms; and (4) a
  # patch roughly in the middle of the Teacher Salaries curve, where the
  # many small, staggered per-school hiring jumps blend into what looks
  # like a smooth line at district scale.
  districtBuildingRegions <- reactive({
    dt <- districtData()
    if (nrow(dt) < 2) {
      return(list())
    }

    building_cum <- dt$total_schools * school_cost
    n <- nrow(dt)

    elem_jump_rows <- which(diff(c(0L, dt$elem_schools)) > 0)
    mid_jump_rows <- which(diff(c(0L, dt$mid_schools)) > 0)
    high_jump_rows <- which(diff(c(0L, dt$high_schools)) > 0)
    any_jump_rows <- which(diff(c(0L, dt$total_schools)) > 0)

    regions <- list()

    # (1) First elementary + first middle + first high school together --
    # almost always within the first handful of admitted students.
    if (
      length(elem_jump_rows) > 0 &&
        length(mid_jump_rows) > 0 &&
        length(high_jump_rows) > 0
    ) {
      first_end <- max(elem_jump_rows[1], mid_jump_rows[1], high_jump_rows[1])
      x_pad <- max(diff(range(dt$students)) * 0.035, 35)
      y_after <- building_cum[first_end]
      y_pad <- max(y_after * 0.3, school_cost * 0.2)
      regions <- c(
        regions,
        list(list(
          key = "first3",
          panel = "Building Expense",
          cx = (dt$students[1] + dt$students[first_end]) / 2,
          cy = y_after / 2,
          rx = (dt$students[first_end] - dt$students[1]) / 2 + x_pad,
          ry = y_after / 2 + y_pad,
          label = paste0(
            "The district opens an elementary, middle, and high school as soon as ",
            "the first few students arrive."
          )
        ))
      )
    }

    # (2) The 3rd elementary-school addition -- both the jump and the flat
    # run that follows it, up until the next building of ANY type opens.
    elem3_row <- NA_integer_
    if (length(elem_jump_rows) >= 3) {
      elem3_row <- elem_jump_rows[3]
      y_before <- if (elem3_row > 1) building_cum[elem3_row - 1] else 0
      y_after <- building_cum[elem3_row]

      later_any <- any_jump_rows[any_jump_rows > elem3_row]
      flat_end_row <- if (length(later_any) > 0) later_any[1] - 1 else n

      xmin <- dt$students[elem3_row]
      xmax <- dt$students[max(flat_end_row, elem3_row)]
      x_pad <- max((xmax - xmin) * 0.15, 35)
      y_pad <- max((y_after - y_before) * 0.5, school_cost * 0.2)

      regions <- c(
        regions,
        list(list(
          key = "elem3",
          panel = "Building Expense",
          cx = (xmin + xmax) / 2,
          cy = (y_before + y_after) / 2,
          rx = (xmax - xmin) / 2 + x_pad,
          ry = (y_after - y_before) / 2 + y_pad,
          label = paste0(
            "Elementary schools are added as enrollment grows. The width of these ",
            "steps is wider than the capacity of an elementary school, because as ",
            "new students are enrolled in the district, not all of them go to an ",
            "elementary school."
          )
        ))
      )
    }

    # (3) The next middle- and high-school additions after that.
    after_row <- if (!is.na(elem3_row)) elem3_row else 0L
    next_mid <- mid_jump_rows[mid_jump_rows > after_row][1]
    next_high <- high_jump_rows[high_jump_rows > after_row][1]
    if (!is.na(next_mid) && !is.na(next_high)) {
      first_row <- min(next_mid, next_high)
      second_row <- max(next_mid, next_high)
      y_before <- if (first_row > 1) building_cum[first_row - 1] else 0
      y_after <- building_cum[second_row]

      xmin <- dt$students[first_row]
      xmax <- dt$students[second_row]
      x_pad <- max((xmax - xmin) * 1.2, 100)
      y_pad <- max((y_after - y_before) * 0.5, school_cost * 0.2)

      regions <- c(
        regions,
        list(list(
          key = "midhigh",
          panel = "Building Expense",
          cx = (xmin + xmax) / 2,
          cy = (y_before + y_after) / 2,
          rx = (xmax - xmin) / 2 + x_pad,
          ry = (y_after - y_before) / 2 + y_pad,
          label = paste0(
            "Middle Schools and High Schools are added at roughly the same cadence. ",
            "Even though middle schools only have on average 75% of the capacity of ",
            "high schools, they only have to serve 3 grades (as opposed to 4 in high ",
            "school). This means they fill to capacity at roughly the same rate."
          )
        ))
      )
    }

    # (4) A patch roughly in the middle of the Teacher Salaries curve.
    teacher_cum <- dt$total_teachers * teacher_cost
    mid_row <- max(1, round(n / 2))
    x_pad <- max(diff(range(dt$students)) * 0.06, 40) * 3
    y_pad <- max(max(teacher_cum) * 0.05, teacher_cost * 0.5) * 3
    regions <- c(
      regions,
      list(list(
        key = "teacher_smooth",
        panel = "Teacher Salaries",
        cx = dt$students[mid_row],
        cy = teacher_cum[mid_row],
        rx = x_pad,
        ry = y_pad,
        label = paste0(
          "While teachers are added in discrete steps, looking at things on a ",
          "district scale makes the costs associated with teachers seem like a ",
          "smoother, almost linear function of students. This is in part because ",
          "the addition of teachers at multiple schools simultaneously do not line ",
          "up with each other. Additionally, the cost of each teacher is a small ",
          "jump of overall district costs."
        )
      ))
    )

    regions
  })

  output$districtCostPlot <- renderPlot({
    dt <- districtData()
    validate(need(
      nrow(dt) > 0,
      "No data to show -- click Trace District Costs."
    ))

    building_cum <- dt$total_schools * school_cost
    supplies_cum <- dt$students * supply_rate
    teacher_cum <- dt$total_teachers * teacher_cost
    total_cum <- building_cum + supplies_cum + teacher_cum
    total_max <- max(total_cum)

    tick_step <- 1e7
    shared_breaks <- seq(
      0,
      ceiling(total_max / tick_step) * tick_step,
      by = tick_step
    )

    # One panel per row: Building, Supplies, Teacher (each a single solid-
    # color ribbon), then Total (the same three, stacked) at the bottom.
    # This is ONE ggplot object faceted by row, with scales = "free_y" AND
    # space = "free_y" -- ggplot's own layout engine then sizes each row's
    # PLOTTING AREA exactly proportional to that row's own data range,
    # correctly separating that from the (small, shared, consistent) strip
    # label and axis chrome. That's what a manual grid.arrange of separate
    # ggplot objects can't guarantee, since each one's title/margins eat a
    # fixed amount of space regardless of how tall its row is assigned to
    # be -- this is why School Supplies looked disproportionately short
    # before. The shared $10,000,000 tick spacing still applies everywhere;
    # a small-range row like Supplies just ends up showing fewer of them.
    long <- rbind(
      data.table(
        students = dt$students,
        ymin = 0,
        ymax = building_cum,
        component = "Building expense",
        panel = "Building Expense"
      ),
      data.table(
        students = dt$students,
        ymin = 0,
        ymax = supplies_cum,
        component = "School supplies",
        panel = "School Supplies"
      ),
      data.table(
        students = dt$students,
        ymin = 0,
        ymax = teacher_cum,
        component = "Teacher salaries",
        panel = "Teacher Salaries"
      ),
      data.table(
        students = dt$students,
        ymin = 0,
        ymax = building_cum,
        component = "Building expense",
        panel = "Total"
      ),
      data.table(
        students = dt$students,
        ymin = building_cum,
        ymax = building_cum + supplies_cum,
        component = "School supplies",
        panel = "Total"
      ),
      data.table(
        students = dt$students,
        ymin = building_cum + supplies_cum,
        ymax = total_cum,
        component = "Teacher salaries",
        panel = "Total"
      )
    )
    long[,
      component := factor(
        component,
        levels = c("Building expense", "School supplies", "Teacher salaries")
      )
    ]
    long[,
      panel := factor(
        panel,
        levels = c(
          "Building Expense",
          "School Supplies",
          "Teacher Salaries",
          "Total"
        )
      )
    ]

    # Highlight ovals: the paired bottom/top "a new school opens" ovals on
    # the Total row, plus the Building Expense callouts. Whichever KEY
    # matches the current click selection is drawn in solid red with a
    # thicker outline -- since both ovals in a Total pair share one key,
    # clicking either highlights both -- same technique as the Elementary
    # and High School tabs otherwise.
    events <- districtSchoolEvents()
    regions <- c(flatten_district_events(events), districtBuildingRegions())
    selected_key <- if (!is.null(districtSelected())) {
      districtSelected()$key
    } else {
      NULL
    }
    ellipse_layers <- NULL
    if (length(regions) > 0) {
      theta <- seq(0, 2 * pi, length.out = 100)
      ellipse_df <- rbindlist(lapply(regions, function(r) {
        poly_id <- if (is.null(r$poly_id)) r$key else r$poly_id
        data.table(
          x = r$cx + r$rx * cos(theta),
          y = r$cy + r$ry * sin(theta),
          region_id = poly_id,
          panel = factor(r$panel, levels = levels(long$panel)),
          selected = identical(r$key, selected_key)
        )
      }))
      ellipse_layers <- list(
        geom_polygon(
          data = ellipse_df,
          aes(
            x = x,
            y = y,
            group = region_id,
            color = selected,
            linewidth = selected,
            linetype = selected
          ),
          inherit.aes = FALSE,
          fill = "white",
          alpha = 0.32
        ),
        scale_color_manual(
          values = c(`TRUE` = "#D7263D", `FALSE` = palette_cb[["ink"]]),
          guide = "none"
        ),
        scale_linewidth_manual(
          values = c(`TRUE` = 2.2, `FALSE` = 0.9),
          guide = "none"
        ),
        scale_linetype_manual(
          values = c(`TRUE` = "solid", `FALSE` = "dashed"),
          guide = "none"
        )
      )
    }

    # Arrows connecting each Total-panel event's bottom oval (on the dark
    # navy Building Expense band) up to its top oval (on the total cost
    # curve), showing that the jump at the bottom shows up at the top too.
    # Colored via the same `selected` mapping/scale as the ovals, so the
    # arrow turns red along with its pair when either oval is clicked.
    arrow_layer <- NULL
    if (length(events) > 0) {
      arrow_df <- rbindlist(lapply(events, function(e) {
        y_from <- e$bottom$cy + e$bottom$ry
        y_to <- e$top$cy - e$top$ry
        data.table(
          x = e$cx,
          xend = e$cx,
          y = y_from,
          yend = max(y_to, y_from + 1),
          panel = factor("Total", levels = levels(long$panel)),
          selected = identical(e$key, selected_key)
        )
      }))
      arrow_layer <- geom_segment(
        data = arrow_df,
        aes(x = x, xend = xend, y = y, yend = yend, color = selected),
        inherit.aes = FALSE,
        linewidth = 0.8,
        arrow = arrow(length = unit(0.2, "cm"), type = "closed")
      )
    }

    ggplot(
      long,
      aes(x = students, ymin = ymin, ymax = ymax, fill = component)
    ) +
      geom_ribbon() +
      {
        if (!is.null(ellipse_layers)) ellipse_layers
      } +
      {
        if (!is.null(arrow_layer)) arrow_layer
      } +
      scale_fill_manual(
        values = c(
          "Building expense" = palette_cb[["ink"]],
          "School supplies" = palette_cb[["facility"]],
          "Teacher salaries" = palette_cb[["highlow"]]
        )
      ) +
      facet_grid(
        rows = vars(panel),
        scales = "free_y",
        space = "free_y",
        labeller = labeller(panel = label_wrap_gen(10))
      ) +
      scale_x_continuous(labels = comma) +
      scale_y_continuous(labels = comma, breaks = shared_breaks) +
      labs(
        title = paste0(
          "Cost Buildup for the Whole District (seed = ",
          input$district_seed,
          ")"
        ),
        x = "Students Enrolled",
        y = "Cost ($)",
        fill = "Cost Component"
      ) +
      theme_minimal(base_size = 12) +
      theme(
        legend.position = "top",
        strip.text.y = element_text(face = "bold", angle = 0),
        panel.spacing = unit(1.4, "lines")
      )
  })

  districtSelected <- reactiveVal(NULL)

  observeEvent(input$districtPlotClick, {
    click <- input$districtPlotClick
    clicked_panel <- click$panelvar1
    hit <- NULL
    if (!is.null(clicked_panel)) {
      all_regions <- c(
        flatten_district_events(districtSchoolEvents()),
        districtBuildingRegions()
      )
      for (r in Filter(function(r) r$panel == clicked_panel, all_regions)) {
        in_oval <- ((click$x - r$cx) / r$rx)^2 + ((click$y - r$cy) / r$ry)^2 <=
          1
        if (isTRUE(in_oval)) {
          hit <- r
          break
        }
      }
    }
    districtSelected(hit)
  })

  observeEvent(districtData(), {
    districtSelected(NULL)
  })

  # Right-hand column, same layout technique as Elementary/High School: one
  # block per facet row, weighted by that row's own peak dollar value. The
  # district's ovals live on the Building Expense, Teacher Salaries, and
  # Total rows, so those are the only blocks that ever show a callout.
  output$districtNotesColumn <- renderUI({
    dt <- districtData()
    if (nrow(dt) == 0) {
      return(NULL)
    }

    w_building <- max(dt$total_schools * school_cost)
    w_supplies <- max(dt$students * supply_rate)
    w_teacher <- max(dt$total_teachers * teacher_cost)
    w_total <- w_building + w_supplies + w_teacher

    sel <- districtSelected()
    note_block <- function(r) {
      if (is.null(r)) {
        return(NULL)
      }
      div(
        class = "situation-card",
        style = "font-size: 13px; line-height: 1.5;",
        HTML(r$label)
      )
    }
    building_note <- if (!is.null(sel) && sel$panel == "Building Expense") {
      note_block(sel)
    } else {
      NULL
    }
    teacher_note <- if (!is.null(sel) && sel$panel == "Teacher Salaries") {
      note_block(sel)
    } else {
      NULL
    }
    total_note <- if (!is.null(sel) && sel$panel == "Total") {
      note_block(sel)
    } else {
      NULL
    }

    header_spacer_px <- 70

    div(
      style = "display: flex; flex-direction: column; height: 900px;",
      div(style = paste0("height: ", header_spacer_px, "px; flex: none;")),
      div(
        style = paste0(
          "flex: ",
          w_building,
          " 1 0; min-height: 110px; display: flex; align-items: center; padding: 4px;"
        ),
        building_note
      ),
      div(style = paste0("flex: ", w_supplies, " 1 0;")),
      div(
        style = paste0(
          "flex: ",
          w_teacher,
          " 1 0; min-height: 110px; display: flex; align-items: center; padding: 4px;"
        ),
        teacher_note
      ),
      div(
        style = paste0(
          "flex: ",
          w_total,
          " 1 0; min-height: 110px; display: flex; align-items: center; padding: 4px;"
        ),
        total_note
      )
    )
  })

  output$districtCostSummary <- renderUI({
    dt <- districtData()
    last <- dt[nrow(dt)]

    total_cost <- last$total_schools *
      school_cost +
      last$students * supply_rate +
      last$total_teachers * teacher_cost

    HTML(paste0(
      "<div style='font-size:15px; line-height:1.7;'>",
      "<b>At ",
      format(last$students, big.mark = ","),
      " students:</b><br>",
      "Elementary: ",
      last$elem_schools,
      " school(s), ",
      last$elem_teachers,
      " teachers<br>",
      "Middle: ",
      last$mid_schools,
      " school(s), ",
      last$mid_teachers,
      " teachers<br>",
      "High: ",
      last$high_schools,
      " school(s), ",
      last$high_teachers,
      " teachers<br><br>",
      "<b>Total schools:</b> ",
      last$total_schools,
      " &nbsp;&nbsp; <b>Total teachers:</b> ",
      last$total_teachers,
      "<br>",
      "<b>Total cost at that enrollment:</b> $",
      format(round(total_cost), big.mark = ","),
      "</div>"
    ))
  })
}

shinyApp(ui, server)
